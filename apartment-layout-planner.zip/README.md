---
title: Apartment Layout Planner
emoji: 🏗️
colorFrom: blue
colorTo: indigo
sdk: static
pinned: false
---