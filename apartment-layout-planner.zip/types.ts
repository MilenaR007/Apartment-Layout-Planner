/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ItemCategory = 'rooms' | 'doors_windows' | 'living_room' | 'bedroom' | 'kitchen' | 'bathroom' | 'decorations';

export interface CatalogItem {
  id: string;
  name: string;
  category: ItemCategory;
  icon: string; // Emoji or short code
  type: 'rect' | 'circle' | 'door' | 'window' | 'rug' | 'plant' | 'path' | 'text' | 'stairs';
  width: number; // raw default width in grid pixels
  height: number; // raw default height in grid pixels
  fill: string;
  stroke: string;
  strokeWidth: number;
  label?: string;
  customProps?: Record<string, any>;
}

export interface SavedProject {
  id: string;
  name: string;
  updatedAt: string;
  canvasData: string; // JSON string from fabric
  scaleFactor: number; // how many cm per pixel (default: 2)
}

export interface CanvasObjectMetadata {
  id: string;
  label?: string;
  baseWidth: number;
  baseHeight: number;
  itemType: string;
}
