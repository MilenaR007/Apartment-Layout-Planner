/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import { fabric } from 'fabric';
import {
  Plus,
  Trash2,
  Copy,
  RotateCw,
  Maximize2,
  Minimize2,
  Download,
  FolderOpen,
  Save,
  Grid,
  Layers,
  Sparkles,
  RefreshCw,
  Search,
  Check,
  Type,
  FileDown,
  Info,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  LayoutGrid,
  FileEdit,
  Sliders,
  Paintbrush,
  Move,
  Layout,
  HelpCircle,
  Scissors,
  Undo2,
  Redo2
} from 'lucide-react';
import { CATALOG, CATEGORY_LABELS } from './catalog';
import { CatalogItem, ItemCategory, SavedProject } from './types';

// Override fabric.Rect.prototype._render to render room labels in top-left corners of rooms
// and beautiful blueprint-style vector blueprints for specific furniture elements
const originalRectRender = fabric.Rect.prototype._render;
fabric.Rect.prototype._render = function (this: any, ctx: CanvasRenderingContext2D) {
  const isStairs = this.isStairs || this.id === 'room_stairs' || this.catalogId === 'room_stairs' || (this.label && this.label.toLowerCase().includes('stairs')) || (this.label && this.label.toLowerCase().includes('schody'));
  const w = this.width || 0;
  const h = this.height || 0;
  const left = -w / 2;
  const top = -h / 2;
  const right = w / 2;
  const bottom = h / 2;

  if (isStairs) {
    ctx.save();
    
    // Draw background fill
    if (this.fill && this.fill !== 'transparent') {
      ctx.fillStyle = this.fill;
      ctx.fillRect(left, top, w, h);
    } else {
      ctx.fillStyle = 'rgba(251, 191, 36, 0.1)';
      ctx.fillRect(left, top, w, h);
    }

    // Draw border
    ctx.strokeStyle = this.stroke || '#d97706';
    ctx.lineWidth = this.strokeWidth || 3;
    ctx.strokeRect(left, top, w, h);

    // Draw steps inside
    ctx.save();
    ctx.strokeStyle = 'rgba(180, 83, 9, 0.45)';
    ctx.lineWidth = 1.2;

    const isVertical = h > w;
    if (isVertical) {
      const stepCount = Math.max(5, Math.floor(h / 18));
      const stepSize = h / stepCount;
      for (let i = 1; i < stepCount; i++) {
        const cy = top + i * stepSize;
        ctx.beginPath();
        ctx.moveTo(left + 1, cy);
        ctx.lineTo(right - 1, cy);
        ctx.stroke();
      }

      // Directional arrow showing ascent in the center
      ctx.strokeStyle = 'rgba(180, 83, 9, 0.7)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, bottom - 15);
      ctx.lineTo(0, top + 15);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-5, top + 22);
      ctx.lineTo(0, top + 15);
      ctx.lineTo(5, top + 22);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(0, bottom - 15, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(180, 83, 9, 0.7)';
      ctx.fill();
    } else {
      const stepCount = Math.max(5, Math.floor(w / 18));
      const stepSize = w / stepCount;
      for (let i = 1; i < stepCount; i++) {
        const cx = left + i * stepSize;
        ctx.beginPath();
        ctx.moveTo(cx, top + 1);
        ctx.lineTo(cx, bottom - 1);
        ctx.stroke();
      }

      // Directional arrow in center
      ctx.strokeStyle = 'rgba(180, 83, 9, 0.7)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(left + 15, 0);
      ctx.lineTo(right - 15, 0);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(right - 22, -5);
      ctx.lineTo(right - 15, 0);
      ctx.lineTo(right - 22, 5);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(left + 15, 0, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(180, 83, 9, 0.7)';
      ctx.fill();
    }
    ctx.restore();

    // Render counter-scaled label
    ctx.save();
    const sX = this.scaleX || 1;
    const sY = this.scaleY || 1;
    ctx.scale(1 / sX, 1 / sY);

    ctx.font = '600 8.5px Inter, "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#b45309'; // Warm amber 700
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    const labelText = this.label || 'Stairs';
    ctx.fillText(labelText, 0, 0);
    ctx.restore();

    ctx.restore();
    return;
  }

  const isRoom = this.isRoom || this.itemCategory === 'rooms';

  const rad = this.cornerRadius !== undefined ? this.cornerRadius : 20;
  const rTL = this.roundTL ? rad : 0;
  const rTR = this.roundTR ? rad : 0;
  const rBR = this.roundBR ? rad : 0;
  const rBL = this.roundBL ? rad : 0;

  if (isRoom) {
    // Custom room rendering without summoning originalRectRender.
    // This allows us to draw only selected walls, round only selected corners, etc.
    ctx.save();
    
    // Draw seamless floor fill
    ctx.beginPath();
    ctx.moveTo(left + rTL, top);
    ctx.lineTo(right - rTR, top);
    if (rTR > 0) ctx.arcTo(right, top, right, top + rTR, rTR);
    ctx.lineTo(right, bottom - rBR);
    if (rBR > 0) ctx.arcTo(right, bottom, right - rBR, bottom, rBR);
    ctx.lineTo(left + rBL, bottom);
    if (rBL > 0) ctx.arcTo(left, bottom, left, bottom - rBL, rBL);
    ctx.lineTo(left, top + rTL);
    if (rTL > 0) ctx.arcTo(left, top, left + rTL, top, rTL);
    ctx.closePath();
    
    if (this.fill && this.fill !== 'transparent') {
      ctx.fillStyle = this.fill;
      ctx.fill();
    }

    // Set CAD styles for walls
    ctx.strokeStyle = this.stroke || '#1e293b';
    ctx.lineWidth = this.strokeWidth !== undefined ? this.strokeWidth : 4;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    if (this.strokeDashArray) {
      ctx.setLineDash(this.strokeDashArray);
    } else {
      ctx.setLineDash([]);
    }

    // Since stroke should draw ONLY the active walls, we render each side
    // Top wall
    if (this.wallTop !== false) {
      ctx.beginPath();
      ctx.moveTo(left + rTL, top);
      ctx.lineTo(right - rTR, top);
      ctx.stroke();
    }
    // Top-Right Corner
    if (this.roundTR && rTR > 0 && this.wallTop !== false && this.wallRight !== false) {
      ctx.beginPath();
      ctx.arc(right - rTR, top + rTR, rTR, -Math.PI / 2, 0);
      ctx.stroke();
    }
    // Right wall
    if (this.wallRight !== false) {
      ctx.beginPath();
      ctx.moveTo(right, top + rTR);
      ctx.lineTo(right, bottom - rBR);
      ctx.stroke();
    }
    // Bottom-Right Corner
    if (this.roundBR && rBR > 0 && this.wallRight !== false && this.wallBottom !== false) {
      ctx.beginPath();
      ctx.arc(right - rBR, bottom - rBR, rBR, 0, Math.PI / 2);
      ctx.stroke();
    }
    // Bottom wall
    if (this.wallBottom !== false) {
      ctx.beginPath();
      ctx.moveTo(right - rBR, bottom);
      ctx.lineTo(left + rBL, bottom);
      ctx.stroke();
    }
    // Bottom-Left Corner
    if (this.roundBL && rBL > 0 && this.wallBottom !== false && this.wallLeft !== false) {
      ctx.beginPath();
      ctx.arc(left + rBL, bottom - rBL, rBL, Math.PI / 2, Math.PI);
      ctx.stroke();
    }
    // Left wall
    if (this.wallLeft !== false) {
      ctx.beginPath();
      ctx.moveTo(left, bottom - rBL);
      ctx.lineTo(left, top + rTL);
      ctx.stroke();
    }
    // Top-Left Corner
    if (this.roundTL && rTL > 0 && this.wallLeft !== false && this.wallTop !== false) {
      ctx.beginPath();
      ctx.arc(left + rTL, top + rTL, rTL, Math.PI, -Math.PI / 2);
      ctx.stroke();
    }

    // Custom drawing details inside rooms (Balcony deck planks or Stairs steps)
    if (this.id === 'room_balcony' || this.catalogId === 'room_balcony' || (this.label && this.label.toLowerCase().includes('balcony')) || (this.label && this.label.toLowerCase().includes('balkon'))) {
      ctx.save();
      ctx.strokeStyle = 'rgba(100, 116, 139, 0.25)';
      ctx.lineWidth = 1;
      const step = 14;
      for (let x = left + step; x < right; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, top + 2);
        ctx.lineTo(x, bottom - 2);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Render floor name counter-scaled
    ctx.save();
    const sX = this.scaleX || 1;
    const sY = this.scaleY || 1;
    ctx.scale(1 / sX, 1 / sY);
    
    ctx.font = '600 10.5px Inter, "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#475569'; // Slate 600
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const labelText = this.label || 'Room';
    const rx = -(w * sX) / 2 + 8;
    const ry = -(h * sY) / 2 + 8;

    const textWidth = ctx.measureText(labelText).width;
    const totalW = w * sX;
    const totalH = h * sY;

    if (totalW > textWidth + 16 && totalH > 24) {
      ctx.fillText(labelText, rx, ry);
    }
    ctx.restore();

    ctx.restore();
  } else {
    originalRectRender.call(this, ctx);
  }

  if (!isRoom && (this.isFurniture || this.itemCategory && ['living_room', 'bedroom', 'kitchen', 'bathroom', 'decorations'].includes(this.itemCategory))) {
    // Render polished CAD-style details on furniture rectangles
    ctx.save();
    
    const strokeColor = this.stroke || '#475569';
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 1.2;

    const catId = this.id || '';

    // 1. SOFAS & ARMCHAIRS
    if (catId.includes('sofa') || catId.includes('armchair')) {
      // Back cushion
      ctx.beginPath();
      ctx.moveTo(left + 5, top + 12);
      ctx.lineTo(right - 5, top + 12);
      ctx.stroke();

      // Left & right armrests
      ctx.strokeRect(left, top + 12, 10, h - 12);
      ctx.strokeRect(right - 10, top + 12, 10, h - 12);

      // Cushion splits
      const splitCount = catId.includes('3seater') ? 3 : (catId.includes('2seater') ? 2 : 1);
      if (splitCount > 1) {
        const seatingW = w - 20;
        const step = seatingW / splitCount;
        for (let i = 1; i < splitCount; i++) {
          const cx = left + 10 + i * step;
          ctx.beginPath();
          ctx.moveTo(cx, top + 12);
          ctx.lineTo(cx, bottom);
          ctx.stroke();
        }
      }
    }
    // 2. BEDS (Double / Single)
    else if (catId.includes('bed')) {
      // Headboard outline
      ctx.fillStyle = 'rgba(230, 235, 245, 0.4)';
      ctx.fillRect(left, top, w, 12);
      ctx.strokeRect(left, top, w, 12);

      // Pillows
      const isDouble = catId.includes('double');
      const pWidth = isDouble ? Math.min(w * 0.38, 48) : Math.min(w * 0.65, 52);
      const pHeight = 22;

      if (isDouble) {
        // Double bed left pillow
        ctx.strokeRect(-w/4 - pWidth/2, top + 18, pWidth, pHeight);
        ctx.strokeRect(-w/4 - pWidth/2 + 2, top + 20, pWidth - 4, pHeight - 4);
        // Double bed right pillow
        ctx.strokeRect(w/4 - pWidth/2, top + 18, pWidth, pHeight);
        ctx.strokeRect(w/4 - pWidth/2 + 2, top + 20, pWidth - 4, pHeight - 4);
      } else {
        // Single bed single central pillow
        ctx.strokeRect(-pWidth/2, top + 18, pWidth, pHeight);
        ctx.strokeRect(-pWidth/2 + 2, top + 20, pWidth - 4, pHeight - 4);
      }

      // Blanket crease fold lines
      ctx.beginPath();
      ctx.moveTo(left, top + 72);
      ctx.lineTo(right, top + 72);
      ctx.stroke();

      ctx.beginPath();
      ctx.setLineDash([4, 3]);
      ctx.moveTo(left, top + 78);
      ctx.lineTo(right, top + 78);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    // 3. STORAGE UNITS (Large wardrobes, Dressers, Nightstands)
    else if (catId.includes('wardrobe')) {
      // High-precision wardrobe diagonal marker crosses
      ctx.strokeStyle = 'rgba(71, 85, 105, 0.18)';
      ctx.beginPath();
      ctx.moveTo(left, top); ctx.lineTo(right, bottom);
      ctx.moveTo(right, top); ctx.lineTo(left, bottom);
      ctx.stroke();

      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 1.2;
      // Draw door split line in middle
      ctx.beginPath();
      ctx.moveTo(0, top);
      ctx.lineTo(0, bottom);
      ctx.stroke();

      // Handles in the middle-front
      ctx.strokeRect(-5, bottom - 3, 4, 3);
      ctx.strokeRect(1, bottom - 3, 4, 3);
    }
    else if (catId.includes('dresser') || catId.includes('nightstand') || catId.includes('rtv_cabinet')) {
      const isRTV = catId.includes('rtv_cabinet');
      const divisions = isRTV ? 2 : (catId.includes('dresser') ? 3 : 1);
      const stepH = h / divisions;

      // Draw horizontal drawers lines
      for (let i = 1; i < divisions; i++) {
        const cy = top + i * stepH;
        ctx.beginPath();
        ctx.moveTo(left, cy);
        ctx.lineTo(right, cy);
        ctx.stroke();
      }

      // Draw knobs/handles on drawers
      ctx.fillStyle = strokeColor;
      for (let i = 0; i < divisions; i++) {
        const cy = top + (i + 0.5) * stepH;
        if (isRTV) {
          ctx.beginPath(); ctx.arc(-w/5, cy, 2, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(w/5, cy, 2, 0, Math.PI * 2); ctx.fill();
        } else {
          ctx.beginPath(); ctx.arc(0, cy, 2.5, 0, Math.PI * 2); ctx.fill();
        }
      }
    }
    // 4. KITCHEN COUNTERS, SINKS, STOVES
    else if (catId.includes('sink')) {
      // Concentric inner basin
      ctx.strokeRect(left + 6, top + 6, w - 12, h - 12);
      ctx.beginPath();
      ctx.ellipse(0, 0, (w-18)/2, (h-18)/2, 0, 0, Math.PI*2);
      ctx.stroke();

      // Outlet drain center circle
      ctx.beginPath();
      ctx.arc(0, 0, 3.5, 0, Math.PI * 2);
      ctx.stroke();

      // Mixer tap structure on backwall of sink (top side)
      ctx.strokeRect(-5, top + 1, 10, 4);
      ctx.beginPath();
      ctx.moveTo(0, top + 5);
      ctx.lineTo(0, top + 13);
      ctx.stroke();
    }
    else if (catId.includes('stove')) {
      // 4 glass stove cooking zones
      ctx.strokeStyle = '#ef4444'; // Red heater highlight lines!
      ctx.lineWidth = 1;
      const bRad1 = Math.min(w, h) * 0.17;
      const bRad2 = Math.min(w, h) * 0.13;

      // Top Left
      ctx.beginPath(); ctx.arc(left + w * 0.28, top + h * 0.28, bRad1, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(left + w * 0.28, top + h * 0.28, bRad1 - 3, 0, Math.PI * 2); ctx.stroke();
      // Top Right
      ctx.beginPath(); ctx.arc(right - w * 0.28, top + h * 0.28, bRad2, 0, Math.PI * 2); ctx.stroke();
      // Bottom Left
      ctx.beginPath(); ctx.arc(left + w * 0.28, bottom - h * 0.28, bRad2, 0, Math.PI * 2); ctx.stroke();
      // Bottom Right
      ctx.beginPath(); ctx.arc(right - w * 0.28, bottom - h * 0.28, bRad1, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(right - w * 0.28, bottom - h * 0.28, bRad1 - 3, 0, Math.PI * 2); ctx.stroke();
    }
    else if (catId.includes('counter')) {
      // Standard kitchen counter countertop rear bevel backline
      ctx.beginPath();
      ctx.moveTo(left, top + 8);
      ctx.lineTo(right, top + 8);
      ctx.stroke();
    }
    // 5. BATH TUB, WC, SHOWER
    else if (catId.includes('bathtub') || catId.includes('bath_tub')) {
      // Concentric bath tub contours
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      // Draw inner capsule structure
      ctx.roundRect(left + 8, top + 8, w - 16, h - 16, 12);
      ctx.stroke();
      // Faucet and drain circle details
      ctx.beginPath();
      ctx.arc(left + 16, 0, 3.5, 0, Math.PI * 2);
      ctx.stroke();
    }
    else if (catId.includes('shower')) {
      // Diagonal cross
      ctx.beginPath();
      ctx.moveTo(left, top); ctx.lineTo(right, bottom);
      ctx.moveTo(right, top); ctx.lineTo(left, bottom);
      ctx.stroke();

      // Drain hole
      ctx.beginPath();
      ctx.arc(0, 0, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.stroke();
    }
    else if (catId.includes('wc')) {
      // Flush tank at back
      ctx.strokeRect(left + 4, top, w - 8, 12);
      // Oval bowl
      ctx.beginPath();
      ctx.ellipse(0, (bottom + top + 12)/2, (w - 12)/2, (h - 18)/2, 0, 0, Math.PI * 2);
      ctx.stroke();
    }
    // 6. DINING AND COFFEE TABLES
    else if (catId.includes('table')) {
      // Inset wood frame perimeter
      ctx.strokeRect(left + 5, top + 5, w - 10, h - 10);
      // Faint crossed structural legs underframe
      ctx.strokeStyle = 'rgba(180, 83, 9, 0.15)';
      ctx.strokeRect(left + 8, top + 8, w - 16, h - 16);
    }

    ctx.restore();

    // RENDER GRACEFUL SMALL GREY NAMES IN THE TOP LEFT CORNER
    ctx.save();
    const sX = this.scaleX || 1;
    const sY = this.scaleY || 1;
    ctx.scale(1 / sX, 1 / sY);

    ctx.font = '500 8.5px Inter, "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#64748b'; // Slate 500
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const labelText = this.label || '';
    if (labelText) {
      const rx = -(w * sX) / 2 + 5;
      const ry = -(h * sY) / 2 + 5;

      const textWidth = ctx.measureText(labelText).width;
      const totalW = w * sX;
      const totalH = h * sY;

      if (totalW > textWidth + 10 && totalH > 18) {
        ctx.fillText(labelText, rx, ry);
      }
    }
    ctx.restore();
  }
};

// Override fabric.Path.prototype._render to draw small names for paths (doors & windows)
const originalPathRender = fabric.Path.prototype._render;
fabric.Path.prototype._render = function (this: any, ctx: CanvasRenderingContext2D) {
  originalPathRender.call(this, ctx);

  if (this.itemCategory === 'doors_windows') {
    ctx.save();
    
    const sX = this.scaleX || 1;
    const sY = this.scaleY || 1;
    ctx.scale(1 / sX, 1 / sY);

    ctx.font = '500 8.5px Inter, "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#64748b'; // Slate 500
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const labelText = this.label || '';
    if (labelText) {
      const w = this.width || 60;
      const h = this.height || 60;
      
      const rx = -(w * sX) / 2 + 5;
      const ry = -(h * sY) / 2 + 5;

      const textWidth = ctx.measureText(labelText).width;
      const totalW = w * sX;
      const totalH = h * sY;

      if (totalW > textWidth + 10 && totalH > 18) {
        ctx.fillText(labelText, rx, ry);
      }
    }
    ctx.restore();
  }
};

// Override fabric.Circle.prototype._render to render potted plants with radiating foliage and pots
const originalCircleRender = fabric.Circle.prototype._render;
fabric.Circle.prototype._render = function (this: any, ctx: CanvasRenderingContext2D) {
  originalCircleRender.call(this, ctx);

  const isPlant = this.isPlant || (this.itemCategory === 'decorations' && (this.id || '').includes('plant'));
  if (isPlant && this.radius) {
    ctx.save();
    const r = this.radius;
    const strokeColor = this.stroke || '#15803d';
    
    ctx.strokeStyle = strokeColor;
    ctx.lineWidth = 1.2;

    // Draw 8 botanical radiating leaf outlines inside the planter circle
    ctx.beginPath();
    for (let i = 0; i < 8; i++) {
      const angle = (i * Math.PI) / 4;
      ctx.moveTo(0, 0);
      const targetX = Math.cos(angle) * r * 0.95;
      const targetY = Math.sin(angle) * r * 0.95;
      
      // Control points for a lovely naturalistic curved leaf shape
      const cpX = Math.cos(angle + 0.25) * r * 0.65;
      const cpY = Math.sin(angle + 0.25) * r * 0.65;
      ctx.quadraticCurveTo(cpX, cpY, targetX, targetY);
    }
    ctx.stroke();

    // Concentric inner clay pot circle core
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.38, 0, Math.PI * 2);
    ctx.fillStyle = '#b45309'; // Warm clay brown center core!
    ctx.fill();
    ctx.stroke();

    ctx.restore();

    // RENDER SLATE GREY NAME
    ctx.save();
    const sX = this.scaleX || 1;
    const sY = this.scaleY || 1;
    ctx.scale(1 / sX, 1 / sY);

    ctx.font = '500 8.5px Inter, "Segoe UI", system-ui, sans-serif';
    ctx.fillStyle = '#64748b'; // Slate 500
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const labelText = this.label || '';
    if (labelText) {
      const w = r * 2;
      const h = r * 2;
      
      const rx = -(w * sX) / 2 + 5;
      const ry = -(h * sY) / 2 + 5;

      const textWidth = ctx.measureText(labelText).width;
      const totalW = w * sX;
      const totalH = h * sY;

      if (totalW > textWidth + 10 && totalH > 18) {
        ctx.fillText(labelText, rx, ry);
      }
    }
    ctx.restore();
  }
};

// Disable object caching globally so that high-precision scaling, zooming, custom borders, 
// and canvas text overrides never get clipped or rendered with blurriness at low dimensions.
fabric.Object.prototype.objectCaching = false;

export default function App() {
  // Elements holding state
  const canvasRef = useRef<fabric.Canvas | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [activeCategory, setActiveCategory] = useState<ItemCategory>('rooms');
  const [selectedObj, setSelectedObj] = useState<fabric.Object | null>(null);

  // Sidebar toggles & reactive triggers
  const [showCatalog, setShowCatalog] = useState<boolean>(true);
  const [sidebarTab, setSidebarTab] = useState<'catalog' | 'saved'>('catalog');
  const [showProperties, setShowProperties] = useState<boolean>(true);
  const [canvasUpdateCounter, setCanvasUpdateCounter] = useState<number>(0);
  const triggerCanvasUpdate = () => setCanvasUpdateCounter(prev => prev + 1);
  
  // Custom tool configurations
  const [projectName, setProjectName] = useState<string>('My Apartment Layout');
  const [savedProjects, setSavedProjects] = useState<SavedProject[]>([]);
  const [showSaveLoadModal, setShowSaveLoadModal] = useState<boolean>(false);
  
  // Custom non-blocking modal system to avoid blocked browser alerts/confirmations (especially in iframe sandboxes)
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<{
    message: string;
    onConfirm: () => void;
  } | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(prev => prev === msg ? null : prev);
    }, 4000); // 4 seconds auto-dismiss
  };

  const triggerConfirm = (message: string, onConfirm: () => void) => {
    setConfirmDialog({
      message,
      onConfirm
    });
  };
  
  // Grid and Snapping state
  const [gridSize, setGridSize] = useState<number>(20);
  const [snapEnabled, setSnapEnabled] = useState<boolean>(true);
  
  // Scale calibration (1px = scaleRatio cm)
  // Default: 1 pixel = 2 cm (so 100 pixels = 2 meters, 50 px = 1 meter)
  const [scaleRatio, setScaleRatio] = useState<number>(2);
  
  // Viewport navigation
  const [zoom, setZoom] = useState<number>(1.0);
  const [panMode, setPanMode] = useState<boolean>(false); // false = select, true = hand pan
  const [isDribbling, setIsDribbling] = useState<boolean>(false);
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [lastPanPos, setLastPanPos] = useState({ x: 0, y: 0 });
  const [statusBarCoords, setStatusBarCoords] = useState({ x: 0, y: 0 });
  
  // Preset palettes for colors
  const colorPresets = [
    { name: 'Slate Wall', value: '#1e293b' },
    { name: 'Indigo Wall', value: '#1e3a8a' },
    { name: 'Oak Wood', value: '#b45309' },
    { name: 'Light Pine', value: '#fef3c7' },
    { name: 'Teal Mint', value: '#0f766e' },
    { name: 'Sage Green', value: '#166534' },
    { name: 'Acrylic White', value: '#ffffff' },
    { name: 'Velvet Gray', value: '#475569' },
    { name: 'Glassy Cyan', value: '#0891b2' },
    { name: 'Brick Walnut', value: '#c2410c' }
  ];

  const fillPresets = [
    { name: 'Transparent', value: 'rgba(255, 255, 255, 0)' },
    { name: 'Light Silver', value: 'rgba(241, 245, 249, 0.4)' },
    { name: 'Warm Sand', value: 'rgba(254, 243, 199, 0.4)' },
    { name: 'Ocean Blue', value: 'rgba(224, 242, 254, 0.5)' },
    { name: 'Pure Mint', value: 'rgba(240, 253, 250, 0.4)' },
    { name: 'Lavender', value: 'rgba(245, 243, 255, 0.4)' },
    { name: 'Deep Charcoal', value: 'rgba(51, 65, 85, 0.15)' },
    { name: 'Sunny Cream', value: 'rgba(254, 243, 199, 0.6)' }
  ];

  // Selected object properties for direct editing in React
  const [objProperties, setObjProperties] = useState({
    label: '',
    widthCm: 0,
    heightCm: 0,
    fill: '',
    stroke: '',
    strokeWidth: 2,
    angle: 0,
    opacity: 1,
    flipX: false,
    flipY: false,
    cornerRadius: 20,
    roundTL: false,
    roundTR: false,
    roundBL: false,
    roundBR: false,
    wallTop: true,
    wallRight: true,
    wallBottom: true,
    wallLeft: true,
    mergedId: null as string | null
  });

  // Undo/Redo State & History Pipeline
  const [canUndo, setCanUndo] = useState<boolean>(false);
  const [canRedo, setCanRedo] = useState<boolean>(false);

  const undoStackRef = useRef<string[]>([]);
  const redoStackRef = useRef<string[]>([]);
  const isHistoryBatchRef = useRef<boolean>(false);
  const saveHistoryTimeoutRef = useRef<any>(null);

  const undoRef = useRef<() => void>(() => {});
  const redoRef = useRef<() => void>(() => {});
  const saveHistoryRef = useRef<() => void>(() => {});

  const saveHistory = (immediate = false) => {
    if (!canvasRef.current || isHistoryBatchRef.current) return;

    const performSave = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const jsonStr = JSON.stringify(canvas.toJSON([
        'id', 'label', 'itemCategory', 'baseItemType', 'isRoom', 'isFurniture', 'isPlant', 'isStairs', 'mergedId', 'catalogId', 'rx', 'ry', 'strokeUniform', 'strokeDashArray', 'cornerRadius', 'roundTL', 'roundTR', 'roundBL', 'roundBR', 'wallTop', 'wallRight', 'wallBottom', 'wallLeft'
      ]));

      if (undoStackRef.current.length > 0 && undoStackRef.current[undoStackRef.current.length - 1] === jsonStr) {
        return;
      }

      undoStackRef.current.push(jsonStr);
      if (undoStackRef.current.length > 50) {
        undoStackRef.current.shift();
      }
      redoStackRef.current = [];
      setCanUndo(undoStackRef.current.length > 1);
      setCanRedo(false);
    };

    if (saveHistoryTimeoutRef.current) {
      clearTimeout(saveHistoryTimeoutRef.current);
    }

    if (immediate) {
      performSave();
    } else {
      saveHistoryTimeoutRef.current = setTimeout(() => {
        performSave();
      }, 300);
    }
  };

  const undo = () => {
    if (!canvasRef.current || undoStackRef.current.length <= 1) return;
    const canvas = canvasRef.current;

    const currentState = undoStackRef.current.pop();
    if (!currentState) return;
    redoStackRef.current.push(currentState);

    const prevState = undoStackRef.current[undoStackRef.current.length - 1];
    if (prevState) {
      isHistoryBatchRef.current = true;
      canvas.loadFromJSON(JSON.parse(prevState), () => {
        canvas.getObjects().forEach(obj => {
          obj.set({
            cornerColor: '#6366f1',
            cornerSize: 10,
            transparentCorners: false,
            borderColor: '#818cf8',
            borderScaleFactor: 2,
          });
        });
        canvas.renderAll();
        setSelectedObj(null);
        triggerCanvasUpdate();
        isHistoryBatchRef.current = false;
      });
    }

    setCanUndo(undoStackRef.current.length > 1);
    setCanRedo(true);
  };

  const redo = () => {
    if (!canvasRef.current || redoStackRef.current.length === 0) return;
    const canvas = canvasRef.current;

    const nextState = redoStackRef.current.pop();
    if (!nextState) return;
    undoStackRef.current.push(nextState);

    isHistoryBatchRef.current = true;
    canvas.loadFromJSON(JSON.parse(nextState), () => {
      canvas.getObjects().forEach(obj => {
        obj.set({
          cornerColor: '#6366f1',
          cornerSize: 10,
          transparentCorners: false,
          borderColor: '#818cf8',
          borderScaleFactor: 2,
        });
      });
      canvas.renderAll();
      setSelectedObj(null);
      triggerCanvasUpdate();
      isHistoryBatchRef.current = false;
    });

    setCanUndo(true);
    setCanRedo(redoStackRef.current.length > 0);
  };

  // Keep references stable for keyboard events & fabric listeners
  useEffect(() => {
    undoRef.current = undo;
    redoRef.current = redo;
    saveHistoryRef.current = () => saveHistory();
  });

  useEffect(() => {
    return () => {
      if (saveHistoryTimeoutRef.current) {
        clearTimeout(saveHistoryTimeoutRef.current);
      }
    };
  }, []);

  // Maintain stable refs for callback inputs to prevent canvas re-initialization teardown
  const panModeRef = useRef<boolean>(panMode);
  const snapEnabledRef = useRef<boolean>(snapEnabled);
  const scaleRatioRef = useRef<number>(scaleRatio);
  const gridSizeRef = useRef<number>(gridSize);
  const isPanningRef = useRef<boolean>(isPanning);
  const lastPanPosRef = useRef<{ x: number; y: number }>(lastPanPos);

  // Synchronize state values with refs immediately
  useEffect(() => { panModeRef.current = panMode; }, [panMode]);
  useEffect(() => { snapEnabledRef.current = snapEnabled; }, [snapEnabled]);
  useEffect(() => { scaleRatioRef.current = scaleRatio; }, [scaleRatio]);
  useEffect(() => { gridSizeRef.current = gridSize; }, [gridSize]);
  useEffect(() => { isPanningRef.current = isPanning; }, [isPanning]);
  useEffect(() => { lastPanPosRef.current = lastPanPos; }, [lastPanPos]);

  // Load existing projects on load
  useEffect(() => {
    loadProjectsList();
  }, []);

  // Initialize fabric canvas
  useEffect(() => {
    const initializedCanvas = new fabric.Canvas('planer-canvas', {
      preserveObjectStacking: true,
      selectionColor: 'rgba(99, 102, 241, 0.15)',
      selectionBorderColor: '#6366f1',
      selectionLineWidth: 1.5,
      fireRightClick: true,
      stopContextMenu: true,
    });

    canvasRef.current = initializedCanvas;

    // Apply background pattern grid
    updateCanvasGrid(initializedCanvas, gridSizeRef.current);

    // Capture initial state for undo stack baseline
    const initialJSON = JSON.stringify(initializedCanvas.toJSON([
      'id', 'label', 'itemCategory', 'baseItemType', 'isRoom', 'isFurniture', 'isPlant', 'isStairs', 'mergedId', 'catalogId', 'rx', 'ry', 'strokeUniform', 'strokeDashArray', 'cornerRadius', 'roundTL', 'roundTR', 'roundBL', 'roundBR', 'wallTop', 'wallRight', 'wallBottom', 'wallLeft'
    ]));
    undoStackRef.current = [initialJSON];
    redoStackRef.current = [];
    setCanUndo(false);
    setCanRedo(false);

    // Bind event handlers
    initializedCanvas.on('selection:created', (e) => handleSelection(e.target));
    initializedCanvas.on('selection:updated', (e) => handleSelection(e.target));
    initializedCanvas.on('selection:cleared', () => handleSelection(null));

    // History changes observers
    initializedCanvas.on('object:added', () => {
      if (saveHistoryRef.current) saveHistoryRef.current();
    });
    initializedCanvas.on('object:removed', () => {
      if (saveHistoryRef.current) saveHistoryRef.current();
    });
    initializedCanvas.on('object:modified', () => {
      if (saveHistoryRef.current) saveHistoryRef.current();
    });
    
    initializedCanvas.on('object:moving', (e) => {
      const obj = e.target;
      if (!obj) return;
      
      if (snapEnabledRef.current) {
        // Snap coordinates to closest multiples of the grid size
        obj.set({
          left: Math.round(obj.left! / gridSizeRef.current) * gridSizeRef.current,
          top: Math.round(obj.top! / gridSizeRef.current) * gridSizeRef.current
        });
      }

      // Handle synchronized movement for merged rooms
      if ((obj as any).mergedId) {
        if ((obj as any).lastLeft === undefined) (obj as any).lastLeft = obj.left!;
        if ((obj as any).lastTop === undefined) (obj as any).lastTop = obj.top!;

        const deltaX = obj.left! - (obj as any).lastLeft;
        const deltaY = obj.top! - (obj as any).lastTop;

        if (deltaX !== 0 || deltaY !== 0) {
          initializedCanvas.getObjects().forEach(o => {
            if (o !== obj && (o as any).mergedId === (obj as any).mergedId) {
              o.set({
                left: o.left! + deltaX,
                top: o.top! + deltaY
              });
              o.setCoords();
            }
          });
        }
      }
      (obj as any).lastLeft = obj.left!;
      (obj as any).lastTop = obj.top!;

      updateStateFromObject(obj);
      triggerCanvasUpdate();
    });

    initializedCanvas.on('object:scaling', (e) => {
      const obj = e.target;
      if (!obj) return;

      const currentWidth = obj.width! * obj.scaleX!;
      const currentHeight = obj.height! * obj.scaleY!;

      let targetWidth = currentWidth;
      let targetHeight = currentHeight;

      if (snapEnabledRef.current) {
        // Snap width/height directly
        targetWidth = Math.round(currentWidth / gridSizeRef.current) * gridSizeRef.current;
        targetHeight = Math.round(currentHeight / gridSizeRef.current) * gridSizeRef.current;
        targetWidth = Math.max(targetWidth, gridSizeRef.current); // Minimum is 1 cell
        targetHeight = Math.max(targetHeight, gridSizeRef.current);
      }

      obj.set({
        scaleX: targetWidth / obj.width!,
        scaleY: targetHeight / obj.height!
      });

      updateStateFromObject(obj);
      triggerCanvasUpdate();
    });

    initializedCanvas.on('object:rotating', (e) => {
      if (e.target) {
        updateStateFromObject(e.target);
        triggerCanvasUpdate();
      }
    });

    initializedCanvas.on('mouse:move', (options) => {
      const pointer = initializedCanvas.getPointer(options.e);
      // Coordinate conversions to meters
      const posX = (pointer.x * scaleRatioRef.current) / 100;
      const posY = (pointer.y * scaleRatioRef.current) / 100;
      setStatusBarCoords({ x: posX, y: posY });

      // If panMode is active and dragging
      if (panModeRef.current && isPanningRef.current && options.e) {
        const mouseEvent = options.e as MouseEvent;
        const vpt = initializedCanvas.viewportTransform;
        if (vpt) {
          vpt[4] += mouseEvent.clientX - lastPanPosRef.current.x;
          vpt[5] += mouseEvent.clientY - lastPanPosRef.current.y;
          initializedCanvas.requestRenderAll();
          
          const newPos = { x: mouseEvent.clientX, y: mouseEvent.clientY };
          setLastPanPos(newPos);
          lastPanPosRef.current = newPos;
        }
      }
    });

    initializedCanvas.on('mouse:down', (options) => {
      const mouseEvent = options.e as MouseEvent;
      if (panModeRef.current && mouseEvent) {
        const startPos = { x: mouseEvent.clientX, y: mouseEvent.clientY };
        setIsPanning(true);
        isPanningRef.current = true;
        setLastPanPos(startPos);
        lastPanPosRef.current = startPos;
      }
    });

    initializedCanvas.on('mouse:up', () => {
      setIsPanning(false);
      isPanningRef.current = false;
    });

    // Smooth mouse wheel zoom centered around mouse pointer location
    initializedCanvas.on('mouse:wheel', (opt) => {
      const delta = opt.e.deltaY;
      let zoomVal = initializedCanvas.getZoom();
      zoomVal *= 0.9995 ** delta;
      
      // Limit zoom between 0.4x and 3.0x
      if (zoomVal > 3.0) zoomVal = 3.0;
      if (zoomVal < 0.4) zoomVal = 0.4;
      
      initializedCanvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoomVal);
      setZoom(zoomVal);
      opt.e.preventDefault();
      opt.e.stopPropagation();
    });

    // Quick keys and navigation keyboard listeners
    let previousPanTogglerState = false;

    const handleKeyDown = (e: KeyboardEvent) => {
      // 0. Undo / Redo Shortcuts
      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key?.toLowerCase() === 'z') {
        if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
          return;
        }
        e.preventDefault();
        if (undoRef.current) undoRef.current();
        return;
      }
      if (((e.ctrlKey || e.metaKey) && e.key?.toLowerCase() === 'y') || ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key?.toLowerCase() === 'z')) {
        if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
          return;
        }
        e.preventDefault();
        if (redoRef.current) redoRef.current();
        return;
      }

      // 1. Delete key active elements removal
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
          return;
        }
        deleteActiveObject();
      }

      // 2. Spacebar held down to activate Pan Mode automatically
      if (e.code === 'Space') {
        if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
          return;
        }
        if (!panModeRef.current) {
          previousPanTogglerState = false;
          setPanMode(true);
        }
        e.preventDefault();
      }

      // 3. Arrow Keys to nudge selected details and offset items smoothly
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
          return;
        }
        const activeObj = initializedCanvas.getActiveObject();
        if (activeObj) {
          const step = e.shiftKey ? gridSizeRef.current : 2; // Shift = 1 full grid cell nudge, Normal = 2px precise nudge
          if (e.key === 'ArrowUp') activeObj.set('top', activeObj.top! - step);
          if (e.key === 'ArrowDown') activeObj.set('top', activeObj.top! + step);
          if (e.key === 'ArrowLeft') activeObj.set('left', activeObj.left! - step);
          if (e.key === 'ArrowRight') activeObj.set('left', activeObj.left! + step);
          
          activeObj.setCoords();
          initializedCanvas.renderAll();
          updateStateFromObject(activeObj);
          triggerCanvasUpdate();
          e.preventDefault();
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
          return;
        }
        setPanMode(previousPanTogglerState);
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Initial setup
    initializedCanvas.renderAll();

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      initializedCanvas.dispose();
      canvasRef.current = null;
    };
  }, []);

  // Dynamically update grid background when gridSize updates
  useEffect(() => {
    if (canvasRef.current) {
      updateCanvasGrid(canvasRef.current, gridSize);
    }
  }, [gridSize]);

  // Synchronise panMode options on the active canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (panMode) {
      canvas.discardActiveObject();
      canvas.selection = false;
      canvas.defaultCursor = 'grab';
      canvas.forEachObject((obj) => {
        obj.selectable = false;
        obj.evented = false;
      });
    } else {
      canvas.selection = true;
      canvas.defaultCursor = 'default';
      canvas.forEachObject((obj) => {
        obj.selectable = true;
        obj.evented = true;
      });
    }

    canvas.discardActiveObject();
    setSelectedObj(null);
    canvas.renderAll();
  }, [panMode]);

  // Handle snapping grid size updates
  const updateCanvasGrid = (canvas: fabric.Canvas, currentGrid: number) => {
    const gridPatternCanvas = document.createElement('canvas');
    // We render a 5x5 sub-grid setup for beautiful blueprint paper styling
    gridPatternCanvas.width = currentGrid * 5;
    gridPatternCanvas.height = currentGrid * 5;
    const ctx = gridPatternCanvas.getContext('2d');
    
    if (ctx) {
      ctx.strokeStyle = '#f1f5f9'; // Soft sub grid
      ctx.lineWidth = 0.8;
      
      for (let i = 0; i < 5; i++) {
        const pos = i * currentGrid;
        ctx.beginPath();
        ctx.moveTo(0, pos);
        ctx.lineTo(currentGrid * 5, pos);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(pos, 0);
        ctx.lineTo(pos, currentGrid * 5);
        ctx.stroke();
      }
      
      // Outer major grid lines representing 2 meters
      ctx.strokeStyle = '#cbd5e1'; 
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(currentGrid * 5, 0);
      ctx.moveTo(0, 0);
      ctx.lineTo(0, currentGrid * 5);
      ctx.stroke();
    }

    const pattern = new fabric.Pattern({
      source: gridPatternCanvas as any,
      repeat: 'repeat'
    });

    canvas.setBackgroundColor(pattern, canvas.renderAll.bind(canvas));
  };

  const handleSelection = (target: fabric.Object | null | undefined) => {
    if (target) {
      setSelectedObj(target);
      updateStateFromObject(target);
      // Initialize drag trackers for the selected object (and its grouped contents if any)
      (target as any).lastLeft = target.left;
      (target as any).lastTop = target.top;
      if (target.type === 'activeSelection') {
        const activeSel = target as fabric.ActiveSelection;
        activeSel.getObjects().forEach((o: any) => {
          o.lastLeft = o.left;
          o.lastTop = o.top;
        });
      }
      setShowProperties(true);
    } else {
      setSelectedObj(null);
    }
  };

  // Sync canvas attributes with the properties react panel
  const updateStateFromObject = (obj: fabric.Object) => {
    const realWidth = Math.round(obj.width! * obj.scaleX!);
    const realHeight = Math.round(obj.height! * obj.scaleY!);
    const currentScale = scaleRatioRef.current;
    
    setObjProperties({
      label: (obj as any).label || 'Element',
      widthCm: Math.round(realWidth * currentScale),
      heightCm: Math.round(realHeight * currentScale),
      fill: obj.fill as string || 'rgba(0,0,0,0)',
      stroke: obj.stroke || '#000005',
      strokeWidth: obj.strokeWidth || 1,
      angle: Math.round(obj.angle || 0),
      opacity: obj.opacity || 1,
      flipX: obj.flipX || false,
      flipY: obj.flipY || false,
      cornerRadius: (obj as any).cornerRadius !== undefined ? (obj as any).cornerRadius : 20,
      roundTL: (obj as any).roundTL || false,
      roundTR: (obj as any).roundTR || false,
      roundBL: (obj as any).roundBL || false,
      roundBR: (obj as any).roundBR || false,
      wallTop: (obj as any).wallTop !== false,
      wallRight: (obj as any).wallRight !== false,
      wallBottom: (obj as any).wallBottom !== false,
      wallLeft: (obj as any).wallLeft !== false,
      mergedId: (obj as any).mergedId || null
    });
  };

  // Pushes property parameters from react side inputs down to fabric objects
  const handlePropChange = (property: string, value: any) => {
    if (!canvasRef.current || !selectedObj) return;
    const canvas = canvasRef.current;
    
    const scaleFactor = scaleRatio;

    if (property === 'label') {
      (selectedObj as any).label = value;
      setObjProperties(prev => ({ ...prev, label: value }));
      // Ensure canvas object is rerendered
      canvas.renderAll();
    } else if (property === 'widthCm') {
      const targetCm = parseFloat(value) || gridSize * scaleFactor;
      // Convert real cm into pixel coordinates - skip grid snapping for manual typing so users have exact millimeter precision!
      let targetPx = targetCm / scaleFactor;
      targetPx = Math.max(targetPx, 1);

      selectedObj.set({
        scaleX: targetPx / selectedObj.width!
      });
      selectedObj.setCoords();
      setObjProperties(prev => ({ ...prev, widthCm: Math.round(targetCm) }));
      canvas.renderAll();
    } else if (property === 'heightCm') {
      const targetCm = parseFloat(value) || gridSize * scaleFactor;
      let targetPx = targetCm / scaleFactor;
      targetPx = Math.max(targetPx, 1);

      selectedObj.set({
        scaleY: targetPx / selectedObj.height!
      });
      selectedObj.setCoords();
      setObjProperties(prev => ({ ...prev, heightCm: Math.round(targetCm) }));
      canvas.renderAll();
    } else if (property === 'fill') {
      selectedObj.set({ fill: value });
      setObjProperties(prev => ({ ...prev, fill: value }));
      canvas.renderAll();
    } else if (property === 'stroke') {
      selectedObj.set({ stroke: value });
      setObjProperties(prev => ({ ...prev, stroke: value }));
      canvas.renderAll();
    } else if (property === 'strokeWidth') {
      const numVal = parseInt(value, 10) || 1;
      selectedObj.set({ strokeWidth: numVal });
      setObjProperties(prev => ({ ...prev, strokeWidth: numVal }));
      canvas.renderAll();
    } else if (property === 'angle') {
      const numVal = parseInt(value, 10) || 0;
      selectedObj.set({ angle: numVal });
      selectedObj.setCoords();
      setObjProperties(prev => ({ ...prev, angle: numVal }));
      canvas.renderAll();
    } else if (property === 'opacity') {
      const numVal = parseFloat(value);
      selectedObj.set({ opacity: numVal });
      setObjProperties(prev => ({ ...prev, opacity: numVal }));
      canvas.renderAll();
    } else if (['cornerRadius', 'roundTL', 'roundTR', 'roundBL', 'roundBR', 'wallTop', 'wallRight', 'wallBottom', 'wallLeft'].includes(property)) {
      (selectedObj as any)[property] = value;
      setObjProperties(prev => ({ ...prev, [property]: value }));
      canvas.renderAll();
      triggerCanvasUpdate();
    }
    saveHistory();
  };

  // Flip coordinates horizontally or vertically
  const flipActive = (axis: 'x' | 'y') => {
    if (!canvasRef.current || !selectedObj) return;
    const canvas = canvasRef.current;
    if (axis === 'x') {
      selectedObj.set('flipX', !selectedObj.flipX);
      setObjProperties(prev => ({ ...prev, flipX: selectedObj.flipX || false }));
    } else {
      selectedObj.set('flipY', !selectedObj.flipY);
      setObjProperties(prev => ({ ...prev, flipY: selectedObj.flipY || false }));
    }
    canvas.renderAll();
    saveHistory(true);
  };

  // Rotate selected object by exactly 90 degrees clockwise
  const rotate90Active = () => {
    if (!canvasRef.current || !selectedObj) return;
    const canvas = canvasRef.current;
    const nextAngle = (Math.round((selectedObj.angle || 0) / 90) * 90 + 90) % 360;
    selectedObj.set('angle', nextAngle);
    selectedObj.setCoords();
    setObjProperties(prev => ({ ...prev, angle: nextAngle }));
    canvas.renderAll();
    saveHistory(true);
  };

  // Add items directly to fabric canvas from our design catalog
  const addItemToCanvas = (item: CatalogItem) => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    // Position elements around center-left so it shows nicely
    const left = gridSize * 4;
    const top = gridSize * 4;
    
    let obj: fabric.Object;

    if (item.type === 'rect') {
      obj = new fabric.Rect({
        left,
        top,
        width: item.width,
        height: item.height,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
        rx: item.customProps?.rx || 0,
        ry: item.customProps?.ry || 0,
        strokeUniform: item.customProps?.strokeUniform ?? true,
        strokeDashArray: item.customProps?.strokeDashArray || null,
      });
    } else if (item.type === 'door') {
      const swing = item.customProps?.swing || 'left_inswing';
      let doorPath = 'M 0 0 L 0 60 A 60 60 0 0 0 60 0 Z';
      if (swing === 'right_inswing') {
        doorPath = 'M 60 0 L 60 60 A 60 60 0 0 1 0 0 Z';
      } else if (swing === 'left_outswing') {
        doorPath = 'M 0 0 L 0 -60 A 60 60 0 0 1 60 0 Z';
      } else if (swing === 'right_outswing') {
        doorPath = 'M 60 0 L 60 -60 A 60 60 0 0 0 0 0 Z';
      } else if (swing === 'double') {
        doorPath = 'M 0 0 L 0 30 A 30 30 0 0 0 30 0 M 60 0 L 60 30 A 30 30 0 0 1 30 0 Z';
      } else if (swing === 'sliding') {
        doorPath = 'M 0 2 L 100 2 M 0 -2 L 50 -2 M 50 6 L 100 6';
      }
      
      obj = new fabric.Path(doorPath, {
        left,
        top,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
        strokeUniform: true,
      });
      // Set to desired scale dimensions from catalogue
      obj.set({
        scaleX: item.width / obj.width!,
        scaleY: item.height / obj.height!,
      });
    } else if (item.type === 'window') {
      const swing = item.customProps?.swing || 'fixed';
      let windowPath = 'M 0 0 L 80 0 L 80 12 L 0 12 Z M 0 6 L 80 6';
      if (swing === 'left_inswing') {
        windowPath = 'M 0 0 L 80 0 L 80 12 L 0 12 Z M 0 6 L 80 6 M 0 12 L 0 60 A 48 48 0 0 0 48 12';
      } else if (swing === 'right_inswing') {
        windowPath = 'M 0 0 L 80 0 L 80 12 L 0 12 Z M 0 6 L 80 6 M 80 12 L 80 60 A 48 48 0 0 1 32 12';
      } else if (swing === 'double') {
        windowPath = 'M 0 0 L 80 0 L 80 12 L 0 12 Z M 0 6 L 80 6 M 0 12 L 0 40 A 28 28 0 0 0 28 12 M 80 12 L 80 40 A 28 28 0 0 1 52 12';
      } else if (swing === 'tilt') {
        windowPath = 'M 0 0 L 80 0 L 80 12 L 0 12 Z M 0 6 L 80 6 M 15 12 L 20 35 L 60 35 L 65 12';
      }
      
      obj = new fabric.Path(windowPath, {
        left,
        top,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
        strokeUniform: true,
      });
      // Set to desired scale dimensions from catalogue
      obj.set({
        scaleX: item.width / obj.width!,
        scaleY: item.height / obj.height!,
      });
    } else if (item.type === 'stairs') {
      obj = new fabric.Rect({
        left,
        top,
        width: item.width,
        height: item.height,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
        strokeUniform: true,
      });
    } else if (item.type === 'plant') {
      // Custom green foliage layered circle structure
      obj = new fabric.Circle({
        left,
        top,
        radius: item.width / 2,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
      });
    } else if (item.type === 'rug') {
      obj = new fabric.Rect({
        left,
        top,
        width: item.width,
        height: item.height,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
        strokeDashArray: item.customProps?.strokeDashArray || null,
        strokeUniform: true,
      });
    } else {
      obj = new fabric.Rect({
        left,
        top,
        width: item.width,
        height: item.height,
        fill: item.fill,
        stroke: item.stroke,
        strokeWidth: item.strokeWidth,
      });
    }

    // Attach identification metadata tags for properties tracking
    const uid = `${item.id}_${Date.now()}`;
    (obj as any).id = uid;
    (obj as any).label = item.label || item.name;
    (obj as any).itemCategory = item.category;
    (obj as any).baseItemType = item.type;
    (obj as any).catalogId = item.id;
    (obj as any).isRoom = item.customProps?.isRoom || false;
    (obj as any).isFurniture = item.customProps?.isFurniture || false;
    (obj as any).isPlant = item.customProps?.isPlant || false;
    (obj as any).isStairs = item.customProps?.isStairs || false;

    // Apply soft layout styling for drag handles
    obj.set({
      cornerColor: '#6366f1',
      cornerSize: 10,
      transparentCorners: false,
      borderColor: '#818cf8',
      borderScaleFactor: 2,
      originX: 'left',
      originY: 'top',
    });

    canvas.add(obj);
    canvas.setActiveObject(obj);
    canvas.renderAll();
    setSelectedObj(obj);
    updateStateFromObject(obj);
    triggerCanvasUpdate();
  };

  // Standalone premium Text Label tool 
  const addTextLabel = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    const textObj = new fabric.IText('Text Label', {
      left: gridSize * 5,
      top: gridSize * 5,
      fontFamily: 'Inter, system-ui, sans-serif',
      fontSize: 16,
      fill: '#1e293b',
      fontWeight: 'bold',
      cornerColor: '#6366f1',
      cornerSize: 8,
      transparentCorners: false,
    });

    (textObj as any).id = `text_${Date.now()}`;
    (textObj as any).label = 'New Text';
    (textObj as any).itemCategory = 'decorations';
    (textObj as any).baseItemType = 'text';

    canvas.add(textObj);
    canvas.setActiveObject(textObj);
    canvas.renderAll();
    setSelectedObj(textObj);
    updateStateFromObject(textObj);
    triggerCanvasUpdate();
  };

  // Auto-align overlapping/adjacent walls for two rooms and hide internal dividing walls
  const autoHideOverlappingWalls = (room1: any, room2: any) => {
    // Get absolute coordinates and scale-applied metrics
    const r1 = {
      l: room1.left,
      t: room1.top,
      w: room1.width * room1.scaleX,
      h: room1.height * room1.scaleY,
      r: 0,
      b: 0
    };
    r1.r = r1.l + r1.w;
    r1.b = r1.t + r1.h;

    const r2 = {
      l: room2.left,
      t: room2.top,
      w: room2.width * room2.scaleX,
      h: room2.height * room2.scaleY,
      r: 0,
      b: 0
    };
    r2.r = r2.l + r2.w;
    r2.b = r2.t + r2.h;

    const tolerance = 20; // snapping and alignment tolerance in pixels

    // Check if vertical coordinates are compatible (they overlap on the Y axis)
    const yOverlaps = !(r1.b <= r2.t || r1.t >= r2.b);
    // Check if horizontal coordinates are compatible (they overlap on the X axis)
    const xOverlaps = !(r1.r <= r2.l || r1.l >= r2.r);

    if (yOverlaps) {
      // Room 1 is immediately left of Room 2
      if (Math.abs(r1.r - r2.l) < tolerance) {
        room2.set({ left: r1.r });
        room2.setCoords();
        room1.wallRight = false;
        room2.wallLeft = false;
        return;
      }
      // Room 1 is immediately right of Room 2
      if (Math.abs(r1.l - r2.r) < tolerance) {
        room2.set({ left: r1.l - r2.w });
        room2.setCoords();
        room1.wallLeft = false;
        room2.wallRight = false;
        return;
      }
    }

    if (xOverlaps) {
      // Room 1 is immediately above Room 2
      if (Math.abs(r1.b - r2.t) < tolerance) {
        room2.set({ top: r1.b });
        room2.setCoords();
        room1.wallBottom = false;
        room2.wallTop = false;
        return;
      }
      // Room 1 is immediately below Room 2
      if (Math.abs(r1.t - r2.b) < tolerance) {
        room2.set({ top: r1.t - r2.h });
        room2.setCoords();
        room1.wallTop = false;
        room2.wallBottom = false;
        return;
      }
    }

    // fallback if they are overlapping heavily
    if (xOverlaps && yOverlaps) {
      const xOverlapAmt = Math.min(r1.r, r2.r) - Math.max(r1.l, r2.l);
      const yOverlapAmt = Math.min(r1.b, r2.b) - Math.max(r1.t, r2.t);

      if (xOverlapAmt < yOverlapAmt) {
        // Closer on the sides
        if (r1.l < r2.l) {
          room1.wallRight = false;
          room2.wallLeft = false;
        } else {
          room1.wallLeft = false;
          room2.wallRight = false;
        }
      } else {
        // Closer on top/bottom
        if (r1.t < r2.t) {
          room1.wallBottom = false;
          room2.wallTop = false;
        } else {
          room1.wallTop = false;
          room2.wallBottom = false;
        }
      }
    }
  };

  // Connect multiple rooms or find and join overlapping structures
  const mergeSelectedRooms = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const activeObjects = canvas.getActiveObjects();
    let roomsToMerge: any[] = [];

    // Filter to room or shape objects (exclude purely text annotations)
    const isRoomObject = (obj: fabric.Object) => {
      const o = obj as any;
      if (o.type === 'text' || o.type === 'i-text') return false;
      return true;
    };

    if (activeObjects && activeObjects.length >= 2) {
      roomsToMerge = activeObjects.filter(isRoomObject);
    } else if (selectedObj && isRoomObject(selectedObj)) {
      // Find all rooms/shapes that collide/touch the currently selected item
      const selRoom = selectedObj as any;
      const otherRooms = canvas.getObjects().filter(o => o !== selRoom && isRoomObject(o));

      const r1 = {
        l: selRoom.left!,
        t: selRoom.top!,
        w: selRoom.width! * selRoom.scaleX!,
        h: selRoom.height! * selRoom.scaleY!,
        r: 0,
        b: 0
      };
      r1.r = r1.l + r1.w;
      r1.b = r1.t + r1.h;

      roomsToMerge = [selRoom];

      otherRooms.forEach((other: any) => {
        const r2 = {
          l: other.left!,
          t: other.top!,
          w: other.width! * other.scaleX!,
          h: other.height! * other.scaleY!,
          r: 0,
          b: 0
        };
        r2.r = r2.l + r2.w;
        r2.b = r2.t + r2.h;

        // Check if there is a touch or overlap within visual range
        const touchX = !(r1.r + 20 < r2.l || r1.l - 20 > r2.r);
        const touchY = !(r1.b + 20 < r2.t || r1.t - 20 > r2.b);

        if (touchX && touchY) {
          roomsToMerge.push(other);
        }
      });
    }

    if (roomsToMerge.length < 2) {
      triggerToast('Proszę zaznaczyć co najmniej 2 sąsiadujące kształty/pokoje (przytrzymując Shift), lub umieścić je obok siebie.');
      return;
    }

    const mergedGroupId = `merge_${Date.now()}`;

    // Loop through rooms to merge and assign grouping IDs and align walls
    for (let i = 0; i < roomsToMerge.length; i++) {
      const rm = roomsToMerge[i];
      // Elevate to first-class room status to enable room features (walls, floor areas, etc.)
      if (!rm.isRoom) {
        rm.isRoom = true;
      }
      if (rm.wallTop === undefined) rm.wallTop = true;
      if (rm.wallRight === undefined) rm.wallRight = true;
      if (rm.wallBottom === undefined) rm.wallBottom = true;
      if (rm.wallLeft === undefined) rm.wallLeft = true;

      rm.mergedId = mergedGroupId;
      rm.lastLeft = rm.left;
      rm.lastTop = rm.top;

      for (let j = 0; j < roomsToMerge.length; j++) {
        if (i !== j) {
          autoHideOverlappingWalls(rm, roomsToMerge[j]);
        }
      }
    }

    canvas.discardActiveObject();
    canvas.renderAll();

    // Select the primary merged room
    const primaryRoom = roomsToMerge[0];
    canvas.setActiveObject(primaryRoom);
    setSelectedObj(primaryRoom);
    updateStateFromObject(primaryRoom);
    triggerCanvasUpdate();
    triggerToast('Pokoje/Kształty zostały pomyślnie połączone w jedno pomieszczenie!');
    saveHistory(true);
  };

  // Resolve grouped room structures back to independent rect spaces
  const disconnectRooms = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedObj) return;

    const selRoom = selectedObj as any;
    const currentGroupId = selRoom.mergedId;
    if (!currentGroupId) return;

    const groupRooms = canvas.getObjects().filter((o: any) => o.mergedId === currentGroupId);

    groupRooms.forEach((room: any) => {
      room.mergedId = null;
      room.wallTop = true;
      room.wallRight = true;
      room.wallBottom = true;
      room.wallLeft = true;
    });

    canvas.renderAll();
    updateStateFromObject(selRoom);
    triggerCanvasUpdate();
    saveHistory(true);
  };

  // Duplicate elements instantly on the screen
  const duplicateActiveObject = () => {
    if (!canvasRef.current || !selectedObj) return;
    const canvas = canvasRef.current;
    
    selectedObj.clone((cloned: fabric.Object) => {
      canvas.discardActiveObject();
      const offset = snapEnabled ? gridSize : 20;
      
      cloned.set({
        left: cloned.left! + offset,
        top: cloned.top! + offset,
        evented: true,
      });

      // Regenerate IDs while preserving type-identifying prefixes for rendering (e.g. sofa, bed)
      const origId = (selectedObj as any).id || '';
      const idParts = origId.split('_');
      const prefix = idParts.length > 1 ? idParts.slice(0, -1).join('_') : 'item';
      (cloned as any).id = `${prefix}_dup_${Date.now()}`;
      (cloned as any).label = `${(selectedObj as any).label || 'Copy'} - Copy`;
      (cloned as any).itemCategory = (selectedObj as any).itemCategory;
      (cloned as any).baseItemType = (selectedObj as any).baseItemType;
      (cloned as any).catalogId = (selectedObj as any).catalogId;
      (cloned as any).isRoom = (selectedObj as any).isRoom || false;
      (cloned as any).isFurniture = (selectedObj as any).isFurniture || false;
      (cloned as any).isPlant = (selectedObj as any).isPlant || false;
      (cloned as any).isStairs = (selectedObj as any).isStairs || false;

      // Copy room custom corner rounding and wall traits
      (cloned as any).cornerRadius = (selectedObj as any).cornerRadius;
      (cloned as any).roundTL = (selectedObj as any).roundTL;
      (cloned as any).roundTR = (selectedObj as any).roundTR;
      (cloned as any).roundBL = (selectedObj as any).roundBL;
      (cloned as any).roundBR = (selectedObj as any).roundBR;
      (cloned as any).wallTop = (selectedObj as any).wallTop;
      (cloned as any).wallRight = (selectedObj as any).wallRight;
      (cloned as any).wallBottom = (selectedObj as any).wallBottom;
      (cloned as any).wallLeft = (selectedObj as any).wallLeft;

      // Ensure properties display nicely
      cloned.set({
        cornerColor: '#6366f1',
        cornerSize: 10,
        transparentCorners: false,
        borderColor: '#818cf8',
        borderScaleFactor: 2,
      });

      canvas.add(cloned);
      canvas.setActiveObject(cloned);
      canvas.requestRenderAll();
      setSelectedObj(cloned);
      updateStateFromObject(cloned);
      triggerCanvasUpdate();
    });
  };

  // Direct element layer controls
  const changeObjectLayer = (action: 'front' | 'back') => {
    if (!canvasRef.current || !selectedObj) return;
    const canvas = canvasRef.current;
    if (action === 'front') {
      selectedObj.bringToFront();
    } else {
      selectedObj.sendToBack();
      // Keep canvas grid behind the scenes
      canvas.getObjects().forEach(o => {
        if ((o as any).isGridPattern) {
          o.sendToBack();
        }
      });
    }
    canvas.renderAll();
    triggerCanvasUpdate();
  };

  // Remove elements from design arena
  const deleteActiveObject = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Retrieve active selection directly from the canvas to avoid stale closures
    const activeObjects = canvas.getActiveObjects();
    if (activeObjects && activeObjects.length > 0) {
      activeObjects.forEach(obj => {
        canvas.remove(obj);
      });
      canvas.discardActiveObject();
      canvas.renderAll();
      setSelectedObj(null);
      triggerCanvasUpdate();
    }
  };

  // Clear Canvas entirely
  const clearDesignWorkspace = () => {
    if (!canvasRef.current) return;
    triggerConfirm(
      'Are you absolutely sure you want to clear the entire canvas layout? All unsaved progress will be lost.',
      () => {
        const canvas = canvasRef.current!;
        isHistoryBatchRef.current = true;
        canvas.getObjects().forEach(obj => {
          canvas.remove(obj);
        });
        canvas.discardActiveObject();
        canvas.renderAll();
        setSelectedObj(null);
        triggerCanvasUpdate();
        isHistoryBatchRef.current = false;
        
        // Save the empty baseline state immediately
        saveHistory(true);
        
        triggerToast('Canvas cleared successfully!');
      }
    );
  };

  // Viewport zoom operations
  const adjustZoom = (factor: 'in' | 'out' | 'reset') => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    let newZoom = zoom;

    if (factor === 'in') {
      newZoom = Math.min(zoom + 0.15, 3.0);
    } else if (factor === 'out') {
      newZoom = Math.max(zoom - 0.15, 0.4);
    } else {
      newZoom = 1.0;
      canvas.setViewportTransform([1, 0, 0, 1, 0, 0]); // Reset panning position as well
      setZoom(1.0);
      canvas.renderAll();
      return;
    }

    const center = canvas.getCenter();
    canvas.zoomToPoint({ x: center.left, y: center.top }, newZoom);
    setZoom(newZoom);
    canvas.renderAll();
  };

  // Project Serialization and storage engines locally
  const loadProjectsList = () => {
    try {
      const stored = localStorage.getItem('planer_projects');
      if (stored) {
        setSavedProjects(JSON.parse(stored));
      }
    } catch {
      console.error('Cannot resolve projects list from localStorage');
    }
  };

  const saveProjectToStore = () => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    const canvasJSON = JSON.stringify(canvas.toJSON(['id', 'label', 'itemCategory', 'baseItemType', 'isRoom', 'isFurniture', 'isPlant', 'isStairs', 'mergedId', 'catalogId', 'rx', 'ry', 'strokeUniform', 'strokeDashArray', 'cornerRadius', 'roundTL', 'roundTR', 'roundBL', 'roundBR', 'wallTop', 'wallRight', 'wallBottom', 'wallLeft']));
    
    const newProject: SavedProject = {
      id: `proj_${Date.now()}`,
      name: projectName.trim() || 'Unnamed Layout',
      updatedAt: new Date().toLocaleString('en-US'),
      canvasData: canvasJSON,
      scaleFactor: scaleRatio
    };

    // Filter duplicates and merge
    const updated = savedProjects.filter(p => p.name !== newProject.name);
    const finalProjects = [newProject, ...updated];

    localStorage.setItem('planer_projects', JSON.stringify(finalProjects));
    setSavedProjects(finalProjects);
    triggerToast(`Project "${newProject.name}" successfully saved!`);
  };

  const loadProjectFromStore = (proj: SavedProject) => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    triggerConfirm(
      `Load design option: "${proj.name}"? This will overwrite the active canvas.`,
      () => {
        isHistoryBatchRef.current = true;
        canvas.loadFromJSON(proj.canvasData, () => {
          // Enforce metadata assignments on reloads
          canvas.getObjects().forEach(obj => {
            obj.set({
              cornerColor: '#6366f1',
              cornerSize: 10,
              transparentCorners: false,
              borderColor: '#818cf8',
              borderScaleFactor: 2,
            });
          });
          
          setScaleRatio(proj.scaleFactor || 2);
          setProjectName(proj.name);
          canvas.renderAll();
          setShowSaveLoadModal(false);
          setSelectedObj(null);
          triggerCanvasUpdate();
          
          isHistoryBatchRef.current = false;
          // Fresh history point
          undoStackRef.current = [];
          redoStackRef.current = [];
          saveHistory(true);
          
          triggerToast(`Loaded "${proj.name}" successfully.`);
        });
      }
    );
  };

  const deleteProjectFromStore = (projId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    const targetProj = savedProjects.find(p => p.id === projId);
    const nameHint = targetProj ? ` "${targetProj.name}"` : '';

    triggerConfirm(
      `Are you sure you want to permanently delete the saved blueprint option${nameHint}?`,
      () => {
        const filtered = savedProjects.filter(p => p.id !== projId);
        localStorage.setItem('planer_projects', JSON.stringify(filtered));
        setSavedProjects(filtered);
        triggerToast('Blueprint deleted successfully.');
      }
    );
  };

  // Image / blueprint exportation
  const exportAsImage = (format: 'png' | 'svg') => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    
    // Clear selection for pure snapshot
    canvas.discardActiveObject();
    canvas.renderAll();

    if (format === 'png') {
      const dataURL = canvas.toDataURL({
        format: 'png',
        quality: 1.0,
        multiplier: 1.5 // High density
      });
      const link = document.createElement('a');
      link.download = `${projectName.toLowerCase().replace(/\s+/g, '_')}_plan.png`;
      link.href = dataURL;
      link.click();
    } else {
      const svgData = canvas.toSVG();
      const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const blobURL = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.download = `${projectName.toLowerCase().replace(/\s+/g, '_')}_plan.svg`;
      link.href = blobURL;
      link.click();
      URL.revokeObjectURL(blobURL);
    }
  };

  // Scan items to compute detailed metric lists of rooms
  const getDynamicRoomsList = () => {
    if (!canvasRef.current) return [];
    const canvas = canvasRef.current;
    
    return canvas.getObjects()
      .filter(obj => (obj as any).isRoom || (obj as any).itemCategory === 'rooms')
      .map(obj => {
        const widthCm = Math.round(obj.width! * obj.scaleX! * scaleRatio);
        const heightCm = Math.round(obj.height! * obj.scaleY! * scaleRatio);
        const widthM = widthCm / 100;
        const heightM = heightCm / 100;
        const areaM2 = widthM * heightM;
        
        return {
          id: (obj as any).id || Math.random().toString(),
          label: (obj as any).label || 'Room',
          dimensions: `${widthM.toFixed(2)}m x ${heightM.toFixed(2)}m`,
          area: areaM2,
          color: obj.stroke || '#475569'
        };
      });
  };

  const roomsList = React.useMemo(() => {
    return getDynamicRoomsList();
  }, [canvasUpdateCounter, scaleRatio]);
  
  const totalApartmentArea = roomsList.reduce((acc, curr) => acc + curr.area, 0);

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-slate-50 font-sans text-slate-800 antialiased" id="main-planer-app">
      
      {/* HEADER BAR */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 bg-white px-5 py-2 shadow-sm shrink-0 z-10" id="header-bar">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-sm">
            <Layout className="h-4 w-4" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <input
                id="project-name-input"
                type="text"
                value={projectName}
                onChange={(e) => setProjectName(e.target.value)}
                className="font-bold text-sm text-slate-900 bg-transparent border-b border-transparent hover:border-slate-200 focus:border-indigo-500 focus:outline-none focus:ring-0 max-w-[200px] md:max-w-xs transition py-0.5"
                placeholder="Name your blueprint layout..."
              />
              <FileEdit className="h-3.5 w-3.5 text-slate-400 pointer-events-none" />
            </div>
            <p className="text-[10px] text-slate-500 leading-none">Interactive Floor Plan & Layout Editor</p>
          </div>
        </div>

        {/* Dynamic Metric Indicator */}
        <div className="hidden lg:flex items-center gap-4 bg-slate-50 rounded-lg px-4 py-1 border border-slate-200" id="total-area-widget">
          <div className="text-right">
            <p className="text-[9px] text-slate-450 uppercase tracking-wider font-semibold">Total Floor Area</p>
            <p className="font-mono text-sm font-bold text-indigo-600">{totalApartmentArea.toFixed(2)} m²</p>
          </div>
          <div className="h-5 w-[1px] bg-slate-200"></div>
          <div className="text-right">
            <p className="text-[9px] text-slate-450 uppercase tracking-wider font-semibold">Total Rooms</p>
            <p className="font-mono text-sm font-bold text-slate-800">{roomsList.length}</p>
          </div>
        </div>

        {/* Global Toolbar Commands */}
        <div className="flex flex-wrap items-center gap-1.5">
          {/* Snap Option Control */}
          <button
            onClick={() => setSnapEnabled(!snapEnabled)}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border transition ${
              snapEnabled
                ? 'bg-indigo-50 border-indigo-200 text-indigo-600 font-bold'
                : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
            title="Toggle grid snapping"
          >
            <Grid className="h-3.5 w-3.5" />
            Snapping: {snapEnabled ? 'On' : 'Off'}
          </button>

          {/* Collapsible Panel Toggles */}
          <button
            onClick={() => setShowCatalog(!showCatalog)}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border transition ${
              showCatalog
                ? 'bg-indigo-50 border-indigo-200 text-indigo-750 font-bold'
                : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
            }`}
            title="Toggle Elements Catalog sidebar"
          >
            <LayoutGrid className="h-3.5 w-3.5" />
            Catalog: {showCatalog ? 'Shown' : 'Hidden'}
          </button>

          <button
            onClick={() => setShowProperties(!showProperties)}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border transition ${
              showProperties
                ? 'bg-indigo-50 border-indigo-200 text-indigo-750 font-bold'
                : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
            }`}
            title="Toggle Parameters & Properties sidebar"
          >
            <Sliders className="h-3.5 w-3.5" />
            Properties: {showProperties ? 'Shown' : 'Hidden'}
          </button>

          {/* Scale selection option */}
          <div className="relative flex items-center bg-white border border-slate-200 rounded-lg px-2 md:px-2.5">
            <span className="text-[9px] text-slate-450 font-mono font-medium mr-1 uppercase">Scale:</span>
            <select
              value={scaleRatio}
              onChange={(e) => setScaleRatio(parseFloat(e.target.value))}
              className="bg-transparent border-none text-xs font-semibold text-slate-700 py-1.5 focus:ring-0 focus:outline-none cursor-pointer"
            >
              <option value="1">1px = 1cm (Fine)</option>
              <option value="2">1px = 2cm (Standard)</option>
              <option value="5">1px = 5cm (Coarse)</option>
            </select>
          </div>

          <div className="h-5 w-[1px] bg-slate-200 mx-0.5 hidden sm:block"></div>

          {/* Save/Load projects */}
          <button
            onClick={() => setShowSaveLoadModal(true)}
            className="flex items-center gap-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-800 px-2.5 py-1.5 text-xs font-semibold transition"
          >
            <FolderOpen className="h-3.5 w-3.5" />
            Load / Save Layout
          </button>

          {/* Fast Save */}
          <button
            onClick={saveProjectToStore}
            className="flex items-center gap-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-2.5 py-1.5 text-xs font-bold shadow-sm transition-colors"
          >
            <Save className="h-3.5 w-3.5" />
            Save State
          </button>

          {/* Primary export menus */}
          <div className="flex rounded-lg overflow-hidden border border-slate-200">
            <button
              onClick={() => exportAsImage('png')}
              className="flex items-center gap-1 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-850 border-r border-slate-200 px-2.5 py-1.5 text-xs font-semibold transition"
              title="Export as high density PNG screenshot"
            >
              <FileDown className="h-3.5 w-3.5" />
              PNG
            </button>
            <button
              onClick={() => exportAsImage('svg')}
              className="flex items-center gap-1 bg-white hover:bg-slate-50 text-slate-600 hover:text-slate-850 px-2.5 py-1.5 text-xs font-semibold transition"
              title="Export as vector SVG schematics"
            >
              SVG
            </button>
          </div>
        </div>
      </header>

      {/* CORE FRAMEWORK PANELS */}
      <main className="flex-grow flex overflow-hidden relative">
        
        {/* LEFT SIDEBAR - ITEMS CATALOG */}
        <aside 
          className={`flex flex-col border-r border-slate-200 bg-white z-10 shrink-0 transition-all duration-300 ${
            showCatalog ? 'w-[325px] opacity-100 visible' : 'w-0 opacity-0 invisible overflow-hidden border-r-0'
          }`}
          id="catalog-sidebar"
        >
          {/* Main Sidebar Tabs */}
          <div className="flex border-b border-slate-200 shrink-0 bg-slate-50/50">
            <button
              onClick={() => setSidebarTab('catalog')}
              className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 border-b-2 ${
                sidebarTab === 'catalog'
                  ? 'border-indigo-600 text-indigo-750 bg-white font-extrabold'
                  : 'border-transparent text-slate-450 hover:text-slate-700 hover:bg-slate-100/50'
              }`}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
              Catalog
            </button>
            <button
              onClick={() => setSidebarTab('saved')}
              className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 border-b-2 ${
                sidebarTab === 'saved'
                  ? 'border-indigo-600 text-indigo-750 bg-white font-extrabold'
                  : 'border-transparent text-slate-450 hover:text-slate-700 hover:bg-slate-100/50'
              }`}
            >
              <FolderOpen className="h-3.5 w-3.5" />
              Saved Layouts ({savedProjects.length})
            </button>
          </div>

          {sidebarTab === 'catalog' ? (
            <div className="flex flex-col flex-grow overflow-hidden">
              {/* Category Tabs */}
              <div className="p-4 border-b border-slate-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                    <LayoutGrid className="h-3.5 w-3.5 text-indigo-500" />
                    Elements Catalog
                  </h3>
                  <button
                    onClick={() => setShowCatalog(false)}
                    className="p-1 rounded-md hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition"
                    title="Hide Elements Catalog"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                </div>
                
                {/* Horizontal tab scrollable on mobile */}
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  {(Object.keys(CATEGORY_LABELS) as ItemCategory[]).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setActiveCategory(cat)}
                      className={`px-2 py-1.5 rounded-md font-semibold text-left transition truncate ${
                        activeCategory === cat
                          ? 'bg-indigo-600 text-white font-bold'
                          : 'bg-slate-50 border border-slate-200/60 hover:bg-slate-100 text-slate-600 hover:text-slate-800'
                      }`}
                    >
                      {CATEGORY_LABELS[cat]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Catalog items list */}
              <div className="flex-grow overflow-y-auto p-4 space-y-3">
                <div className="space-y-2">
                  <button
                    onClick={addTextLabel}
                    className="w-full flex items-center justify-between gap-3 text-left p-2.5 rounded-xl bg-slate-50 hover:bg-indigo-50/50 border border-slate-205 hover:border-indigo-400 text-slate-700 hover:text-indigo-700 transition group"
                  >
                    <div className="flex items-center gap-2">
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600 group-hover:scale-110 transition">
                        <Type className="h-4 w-4" />
                      </span>
                      <div>
                        <h4 className="font-bold text-sm">Text Annotation</h4>
                        <p className="text-[11px] text-slate-500">Add custom labels to plans</p>
                      </div>
                    </div>
                    <Plus className="h-4 w-4 text-slate-500 group-hover:text-indigo-400" />
                  </button>
                </div>

                <div className="h-[1px] bg-slate-100"></div>

                <p className="text-[11px] font-semibold text-slate-400 tracking-wider uppercase">Click to add to canvas:</p>

                <div className="grid grid-cols-1 gap-2">
                  {CATALOG.filter(item => item.category === activeCategory).map(item => {
                    // Determine real-world proportions in meters
                    const realW = (item.width * scaleRatio) / 100;
                    const realH = (item.height * scaleRatio) / 100;
                    
                    return (
                      <button
                        key={item.id}
                        onClick={() => addItemToCanvas(item)}
                        className="flex items-center justify-between text-left p-2.5 rounded-xl bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-400/80 text-slate-700 hover:text-indigo-700 transition group"
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-xl p-1.5 bg-white border border-slate-200 rounded-lg group-hover:scale-110 transition-transform">
                            {item.icon}
                          </span>
                          <div>
                            <h4 className="font-bold text-sm leading-tight text-slate-800">{item.name}</h4>
                            <p className="text-[11px] text-slate-500 font-mono">
                              Dimensions: {realW.toFixed(2)}m x {realH.toFixed(2)}m
                            </p>
                          </div>
                        </div>
                        <Plus className="h-4 w-4 text-slate-500 group-hover:text-indigo-600" />
                      </button>
                    );
                  })}
                </div>
              </div>


            </div>
          ) : (
            <div className="flex-grow flex flex-col overflow-hidden">
              {/* Save Layout point */}
              <div className="p-4 border-b border-slate-150 bg-slate-50/50 space-y-3 shrink-0">
                <div className="flex items-center justify-between mb-0.5">
                  <span className="text-[10px] font-bold text-slate-450 uppercase tracking-wider flex items-center gap-1">
                    <Save className="h-3 w-3 text-indigo-550" />
                    Save Instant Blueprint
                  </span>
                  <button
                    onClick={() => setShowCatalog(false)}
                    className="p-1 rounded-md hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition"
                    title="Hide Elements Catalog"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="sidebar-project-name" className="block text-xs font-semibold text-slate-600">
                    Active Layout Name
                  </label>
                  <input
                    type="text"
                    id="sidebar-project-name"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Enter design name..."
                    className="w-full text-slate-800 bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs font-semibold focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none transition-shadow"
                  />
                </div>
                <button
                  onClick={saveProjectToStore}
                  className="w-full flex items-center justify-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white py-2 px-3 text-xs font-bold shadow-sm transition active:bg-indigo-800"
                >
                  <Save className="h-3.5 w-3.5" />
                  Save / Store Layout
                </button>
              </div>

              {/* Saved blueprints history list */}
              <div className="flex-grow overflow-y-auto p-4 space-y-3">
                <h3 className="text-[11px] font-bold text-slate-400 tracking-wider uppercase">Stored Projects List:</h3>
                {savedProjects.length > 0 ? (
                  <div className="space-y-2.5">
                    {savedProjects.map((proj) => (
                      <div
                        key={proj.id}
                        className="p-3 rounded-xl bg-slate-50 border border-slate-200 hover:border-slate-300 transition duration-200 text-left space-y-2.5 relative group"
                      >
                        <div>
                          <h4 className="font-extrabold text-sm text-slate-800 leading-snug break-words pr-6">
                            {proj.name}
                          </h4>
                          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[10px] text-slate-450 mt-1 font-mono">
                            <span>Saved: {proj.updatedAt}</span>
                            <span className="bg-slate-200/50 px-1 py-0.1 rounded text-[9px] uppercase font-bold text-slate-650">
                              Scale 1:{proj.scaleFactor}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => loadProjectFromStore(proj)}
                            className="flex-1 flex items-center justify-center gap-1 py-1.5 px-2.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 hover:text-indigo-850 text-xs font-bold transition cursor-pointer"
                            title="Load layout"
                          >
                            <FolderOpen className="h-3.5 w-3.5" />
                            Load
                          </button>
                          <button
                            onClick={(e) => deleteProjectFromStore(proj.id, e)}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-600 hover:text-rose-700 transition cursor-pointer"
                            title="Delete permanently"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-6 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50/20 text-slate-400 space-y-2">
                    <p className="text-3xl">🗄️</p>
                    <p className="text-xs leading-normal font-medium">
                      No saved layout files detected. Give your active layout a custom name above and click "Save / Store Layout"!
                    </p>
                  </div>
                )}
              </div>

              {/* Restore Point Warning info */}
              <div className="p-4 border-t border-slate-100 bg-slate-50 text-slate-500 text-xs shrink-0">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 text-slate-450 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-700">Restore Warning:</p>
                    <p className="text-[10px] text-slate-500 mt-0.5 leading-normal">
                      Loading any prior layout overwrites your current active canvas scope. Save your current floorplan first!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </aside>

        {/* CENTER PANEL - CANVAS WORKSPACE */}
        <div className="flex-grow flex flex-col bg-slate-100 p-6 relative overflow-hidden" id="canvas-workspace">
          
          {/* Left collapse restore tab */}
          {!showCatalog && (
            <button
              onClick={() => setShowCatalog(true)}
              className="absolute left-0 top-1/2 -translate-y-1/2 flex items-center justify-center h-16 w-5 bg-white border-y border-r border-slate-200 rounded-r-xl shadow-md hover:bg-slate-50 text-slate-400 hover:text-indigo-600 transition z-20 group cursor-pointer border-l bg-white/95 backdrop-blur-sm"
              title="Expand Catalog"
            >
              <ChevronRight className="h-4 w-4 group-hover:scale-110 transition" />
            </button>
          )}

          {/* Right collapse restore tab */}
          {!showProperties && (
            <button
              onClick={() => setShowProperties(true)}
              className="absolute right-0 top-1/2 -translate-y-1/2 flex items-center justify-center h-16 w-5 bg-white border-y border-l border-slate-200 rounded-l-xl shadow-md hover:bg-slate-50 text-slate-400 hover:text-indigo-600 transition z-20 group cursor-pointer border-r bg-white/95 backdrop-blur-sm"
              title="Expand Properties"
            >
              <ChevronLeft className="h-4 w-4 group-hover:scale-110 transition" />
            </button>
          )}
          
          {/* Floating mini toolbar controls atop canvas container */}
          <div className="absolute top-10 left-10 flex items-center gap-1.5 bg-white/95 border border-slate-200 px-3 py-1.5 rounded-xl shadow-xl backdrop-blur-sm z-10">
            {/* SELECT MODES */}
            <button
              onClick={() => setPanMode(false)}
              className={`p-2 rounded-lg transition ${
                !panMode ? 'bg-indigo-600 text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-800'
              }`}
              title="Select pointer mode (drag, resize, select)"
            >
              <Layout className="h-4 w-4" />
            </button>
            <button
              onClick={() => setPanMode(true)}
              className={`p-2 rounded-lg transition ${
                panMode ? 'bg-indigo-600 text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-800'
              }`}
              title="Pan mode (Space + click & drag view)"
            >
              <Move className="h-4 w-4" />
            </button>

            <div className="h-4 w-[1px] bg-slate-200 mx-1"></div>

            {/* ZOOM ACTIONS */}
            <button
              onClick={() => adjustZoom('in')}
              className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition"
              title="Zoom In"
            >
              <Maximize2 className="h-4 w-4" />
            </button>
            <span className="text-xs font-mono font-bold text-slate-700 min-w-[40px] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => adjustZoom('out')}
              className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition"
              title="Zoom Out"
            >
              <Minimize2 className="h-4 w-4" />
            </button>
            <button
              onClick={() => adjustZoom('reset')}
              className="p-1 px-1.5 text-[10px] font-bold border border-slate-200 rounded-md hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition"
              title="Reset Zoom to 100%"
            >
              1:1
            </button>

            <div className="h-4 w-[1px] bg-slate-200 mx-1"></div>

            {/* UNDO / REDO ACTIONS */}
            <button
              onClick={undo}
              disabled={!canUndo}
              className={`p-2 rounded-lg transition ${
                canUndo 
                  ? 'hover:bg-slate-100 text-slate-600 hover:text-slate-900 cursor-pointer' 
                  : 'text-slate-200 cursor-not-allowed'
              }`}
              title="Cofnij / Undo (Ctrl+Z)"
            >
              <Undo2 className="h-4 w-4" />
            </button>
            <button
              onClick={redo}
              disabled={!canRedo}
              className={`p-2 rounded-lg transition ${
                canRedo 
                  ? 'hover:bg-slate-100 text-slate-600 hover:text-slate-900 cursor-pointer' 
                  : 'text-slate-200 cursor-not-allowed'
              }`}
              title="Ponów / Redo (Ctrl+Y)"
            >
              <Redo2 className="h-4 w-4" />
            </button>

            <div className="h-4 w-[1px] bg-slate-200 mx-1"></div>

            {/* CLEAR ALL BUTTON */}
            <button
              onClick={clearDesignWorkspace}
              className="p-2 rounded-lg hover:bg-red-50 text-slate-500 hover:text-red-600 transition"
              title="Clear complete workspace layout"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>

          {/* Core Interactive Drawing Canvas Frame */}
          <div className="flex-grow flex items-center justify-center p-4 overflow-auto rounded-2xl bg-white border border-slate-200 custom-stage shadow-sm">
            <div className="canvas-container relative bg-white select-none shadow-2xl rounded-sm border border-slate-300">
              <canvas id="planer-canvas" width="1050" height="750"></canvas>
            </div>
          </div>

          {/* REALTIME BLUEPRINT FOOTER BAR */}
          <footer className="mt-4 flex flex-col md:flex-row justify-between items-center gap-4 bg-white border border-slate-200 p-4 rounded-xl text-xs text-slate-500 font-medium shadow-sm">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-slate-800 font-bold">Studio Active</span>
              </div>
              <div className="text-slate-350">|</div>
              <div>
                Grid Snapping Resolution: <span className="font-mono text-indigo-600 font-semibold">{gridSize} px ({gridSize * scaleRatio} cm)</span>
              </div>
            </div>

            {/* Modern dynamic scale bar index */}
            <div className="flex items-center gap-3 bg-slate-50 border border-slate-200 px-3.5 py-1.5 rounded-lg">
              <span className="text-slate-450 font-mono text-[10px] uppercase font-bold tracking-wider">Scale Indicator:</span>
              <div className="flex flex-col items-center">
                <div className="w-[100px] h-1.5 border-x border-b border-indigo-500 flex justify-between relative">
                  <span className="absolute -top-3.5 left-0 text-[9px] font-mono font-bold text-slate-450 font-semibold">0</span>
                  <span className="absolute -top-3.5 right-0 text-[9px] font-mono font-bold text-slate-450 font-semibold">
                    {((100 * scaleRatio) / 100).toFixed(1)}m
                  </span>
                </div>
              </div>
            </div>

            {/* Coordinates widget */}
            <div className="font-mono text-[11px] text-slate-600 flex items-center gap-1">
              <span className="text-slate-405 font-semibold">Cursor:</span>
              <span className="bg-slate-50 border border-slate-200 px-2 py-0.5 rounded text-indigo-600 font-bold">
                X: {statusBarCoords.x.toFixed(2)}m
              </span>
              <span className="bg-slate-50 border border-slate-200 px-2 py-0.5 rounded text-indigo-600 font-bold">
                Y: {statusBarCoords.y.toFixed(2)}m
              </span>
            </div>
          </footer>
        </div>

        {/* RIGHT PANEL - DETAILED PROPERTIES SIDEBAR / SUMMARY */}
        <aside 
          className={`flex flex-col border-l border-slate-200 bg-white z-10 shrink-0 transition-all duration-300 ${
            showProperties ? 'w-[330px] opacity-100 visible' : 'w-0 opacity-0 invisible overflow-hidden border-l-0'
          }`}
          id="properties-panel"
        >
          
          {/* Header Title for Properties tab */}
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
              <Sliders className="h-3.5 w-3.5 text-indigo-500" />
              Parameters & Properties
            </h3>
            <div className="flex items-center gap-1.5">
              {selectedObj && (
                <span className="bg-indigo-100 text-indigo-700 text-[10px] font-extrabold px-2 py-0.5 rounded uppercase tracking-wider">
                  Selected
                </span>
              )}
              <button
                onClick={() => setShowProperties(false)}
                className="p-1 rounded-md hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition"
                title="Hide Parameters & Properties"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="flex-grow overflow-y-auto">
            {selectedObj ? (
              selectedObj.type === 'activeSelection' ? (
                <div className="p-5 space-y-6">
                  {/* Element Descriptor Card */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-250/60 space-y-2">
                    <p className="text-[10px] text-indigo-650 uppercase tracking-widest font-mono font-bold">Selection Type:</p>
                    <p className="text-sm font-extrabold text-slate-850 capitalize leading-tight flex items-center gap-1.5">
                      <Layers className="h-4 w-4 text-indigo-500" />
                      Multi-Selection
                    </p>
                    {canvasRef.current && (
                      <p className="text-xs text-slate-500">
                        Selected items: <span className="font-bold text-slate-800 font-mono">{canvasRef.current.getActiveObjects().length}</span>
                      </p>
                    )}
                  </div>

                  {/* Multi-room Connection Panel */}
                  {canvasRef.current && canvasRef.current.getActiveObjects().length >= 2 ? (
                    <div className="space-y-4 p-4 bg-indigo-50/50 border border-indigo-150 rounded-xl">
                      <div className="flex items-center gap-1.5 border-b border-indigo-100 pb-2 bg-transparent text-indigo-900">
                        <span className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                          <span>🔗</span> Połącz kształty / Merge Shapes
                        </span>
                      </div>
                      
                      <div className="space-y-3 text-left">
                        <p className="text-xs text-slate-600 leading-normal font-semibold">
                          Combine selected shapes into a single room. Common dividing walls will automatically be hidden, and they will drag together!
                        </p>
                        <p className="text-[11px] text-slate-500 leading-normal">
                          Połącz zaznaczone kształty w jedno pomieszczenie. Wspólne ściany zostaną automatycznie ukryte, a pokoje będą przesuwać się razem.
                        </p>

                        {/* Sum of area display */}
                        <div className="p-2 bg-white border border-indigo-100 rounded-lg flex justify-between items-center text-xs">
                          <span className="text-slate-500 font-medium">Combined Area / Powierzchnia:</span>
                          <span className="font-mono font-bold text-sm text-indigo-700">
                            {(canvasRef.current.getActiveObjects()
                              .reduce((sum, o) => {
                                const w = (o.width! * o.scaleX! * scaleRatio) / 100;
                                const h = (o.height! * o.scaleY! * scaleRatio) / 100;
                                return sum + (w * h);
                              }, 0)).toFixed(2)} m²
                          </span>
                        </div>

                        <button
                          onClick={mergeSelectedRooms}
                          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-lg text-xs tracking-wide transition active:bg-indigo-800 shadow-sm flex items-center justify-center gap-1.5 cursor-pointer uppercase"
                        >
                          🔗 Połącz Kształty / Merge Shapes
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-left space-y-2">
                      <span className="text-xs font-bold text-slate-600 block">💡 Wskazówka / Merge Tip:</span>
                      <p className="text-xs text-slate-505 leading-normal">
                        Hold <kbd className="bg-white border rounded px-1.5 py-0.5 text-[10px] font-semibold shadow-sm">Shift</kbd> and select at least <strong>two shapes</strong> (lub zaznacz obszar). A dedicated option will show up here to hide dividing walls and connect them!
                      </p>
                    </div>
                  )}

                  {/* DESTRUCTIVE TRASH TRIGGER */}
                  <div className="pt-2">
                    <button
                      onClick={deleteActiveObject}
                      className="w-full flex items-center justify-center gap-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 p-3 text-xs font-bold tracking-wider transition uppercase"
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete Selected Elements
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-5 space-y-6">
                  {/* Element Descriptor Card */}
                  <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-250/60 space-y-2">
                  <p className="text-[10px] text-indigo-600 uppercase tracking-widest font-mono font-bold">Element Type:</p>
                  <p className="text-sm font-extrabold text-slate-850 capitalize leading-tight">
                    {(selectedObj as any).baseItemType || 'Furniture'} / {(selectedObj as any).itemCategory || 'Catalog'}
                  </p>
                  
                  {/* Realtime Calculated Area for ROOMS */}
                  {((selectedObj as any).isRoom || (selectedObj as any).itemCategory === 'rooms') && (
                    <div className="mt-3 pt-2.5 border-t border-slate-200 flex justify-between items-center text-xs">
                      <span className="text-slate-505 font-medium">Calculated Floor Area:</span>
                      <span className="font-mono font-bold text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                        {((objProperties.widthCm / 100) * (objProperties.heightCm / 100)).toFixed(2)} m²
                      </span>
                    </div>
                  )}
                </div>

                {/* Main editable options form */}
                <div className="space-y-4">
                  
                  {/* Customizable text string labelling */}
                  <div>
                    <label htmlFor="prop-label-input" className="block text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1.5"> Label/Name Display </label>
                    <input
                      id="prop-label-input"
                      type="text"
                      className="w-full bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-semibold rounded-lg px-3 py-2 text-slate-855 transition"
                      value={objProperties.label}
                      onChange={(e) => handlePropChange('label', e.target.value)}
                    />
                  </div>

                  {/* SIZES - CENTIMETERS DRIVEN */}
                  <div className="grid grid-cols-2 gap-3" id="dimensions-editor-inputs">
                    <div>
                      <label htmlFor="prop-width-input" className="block text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1.5"> Width (cm) </label>
                      <input
                        id="prop-width-input"
                        type="number"
                        className="w-full font-mono bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-bold rounded-lg px-3 py-2 text-slate-855 transition"
                        value={objProperties.widthCm}
                        onChange={(e) => handlePropChange('widthCm', e.target.value)}
                      />
                    </div>
                    <div>
                      <label htmlFor="prop-height-input" className="block text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1.5"> Height/Length (cm) </label>
                      <input
                        id="prop-height-input"
                        type="number"
                        className="w-full font-mono bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-sm font-bold rounded-lg px-3 py-2 text-slate-855 transition"
                        value={objProperties.heightCm}
                        onChange={(e) => handlePropChange('heightCm', e.target.value)}
                      />
                    </div>
                  </div>

                  {/* ROTATIONS & SPATIAL POSITIONS */}
                  <div className="space-y-2">
                    <p className="block text-xs text-slate-500 font-semibold uppercase tracking-wider mb-1.5"> Spatial Alignment & Rotations </p>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={rotate90Active}
                        className="flex justify-center items-center gap-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-905 p-2.5 text-xs font-semibold text-slate-700 transition shadow-sm"
                        title="Rotate element by 90 degrees clockwise"
                      >
                        <RotateCw className="h-3.5 w-3.5 text-indigo-500" />
                        Rotate 90°
                      </button>
                      <span className="flex items-center justify-center bg-slate-55 rounded-lg px-3 font-mono text-xs border border-slate-200 font-bold text-slate-755">
                        {objProperties.angle}°
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-2">
                      <button
                        onClick={() => flipActive('x')}
                        className={`flex justify-center items-center gap-1.5 rounded-lg border p-2.5 text-xs font-semibold transition ${
                          objProperties.flipX 
                            ? 'bg-indigo-600 border-indigo-650 text-white shadow-sm' 
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                        title="Flip horizontally"
                      >
                        Flip axis X
                      </button>
                      <button
                        onClick={() => flipActive('y')}
                        className={`flex justify-center items-center gap-1.5 rounded-lg border p-2.5 text-xs font-semibold transition ${
                          objProperties.flipY 
                            ? 'bg-indigo-600 border-indigo-655 text-white shadow-sm' 
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                        title="Flip vertically"
                      >
                        Flip axis Y
                      </button>
                    </div>
                  </div>

                  {/* COHESIVE PALETTE SELECTION FOR THE ARCHITECTURAL BOARD */}
                  <div className="space-y-3">
                    <div className="flex items-center gap-1">
                      <Paintbrush className="h-3.5 w-3.5 text-indigo-505" />
                      <p className="block text-xs text-slate-500 font-semibold uppercase tracking-wider"> Color & Styling </p>
                    </div>

                    {/* Fills pallet */}
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Zone Fill Color:</span>
                      <div className="grid grid-cols-4 gap-1.5 mt-1.5 bg-slate-50 p-2 rounded-xl border border-slate-200">
                        {fillPresets.map((f, i) => (
                          <button
                            key={i}
                            className={`w-full h-8 rounded-lg border relative transition-all ${
                              objProperties.fill === f.value
                                ? 'border-indigo-600 scale-105 shadow-sm ring-2 ring-indigo-500'
                                : 'border-slate-200 hover:border-slate-400'
                            }`}
                            style={{ 
                              backgroundColor: f.value === 'rgba(255, 255, 255, 0)' ? 'transparent' : f.value,
                              backgroundImage: f.value === 'rgba(255, 255, 255, 0)' ? 'linear-gradient(45deg, #ccc 25%, transparent 25%), linear-gradient(-45deg, #ccc 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #ccc 75%), linear-gradient(-45deg, transparent 75%, #ccc 75%)' : 'none',
                              backgroundSize: f.value === 'rgba(255, 255, 255, 0)' ? '8px 8px' : 'auto',
                              backgroundPosition: f.value === 'rgba(255, 255, 255, 0)' ? '0 0, 0 4px, 4px -4px, -4px 0' : 'auto'
                            }}
                            onClick={() => handlePropChange('fill', f.value)}
                            title={f.name}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Outline Border palette */}
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Wall / Border Color:</span>
                      <div className="grid grid-cols-5 gap-1.5 mt-1.5 bg-slate-50 p-2 rounded-xl border border-slate-200">
                        {colorPresets.map((c, i) => (
                          <button
                            key={i}
                            className={`h-6 rounded-md border transition-all ${
                              objProperties.stroke === c.value
                                ? 'border-slate-900 !ring-2 ring-indigo-500 scale-105'
                                : 'border-slate-200 hover:border-slate-400'
                            }`}
                            style={{ backgroundColor: c.value }}
                            onClick={() => handlePropChange('stroke', c.value)}
                            title={c.name}
                          />
                        ))}
                      </div>
                    </div>

                    {/* Custom Stroke Width slider */}
                    <div>
                      <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                        <span>Stroke / Line Weight:</span>
                        <span className="font-mono text-slate-650">{objProperties.strokeWidth} px</span>
                      </div>
                      <input
                        id="stroke-width-slider"
                        type="range"
                        min="1"
                        max="8"
                        className="w-full accent-indigo-550 h-1 bg-slate-200 rounded-lg cursor-pointer mt-1"
                        value={objProperties.strokeWidth}
                        onChange={(e) => handlePropChange('strokeWidth', e.target.value)}
                      />
                    </div>

                    {/* Opacity level picker */}
                    <div>
                      <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                        <span>Opacity (Alpha):</span>
                        <span className="font-mono text-slate-650">{Math.round(objProperties.opacity * 100)} %</span>
                      </div>
                      <input
                        id="opacity-slider"
                        type="range"
                        min="0.1"
                        max="1.0"
                        step="0.05"
                        className="w-full accent-indigo-550 h-1 bg-slate-200 rounded-lg cursor-pointer mt-1"
                        value={objProperties.opacity}
                        onChange={(e) => handlePropChange('opacity', e.target.value)}
                      />
                    </div>
                  </div>

                  {/* ROOM SPECIFIC CONFIGURATION: CUSTOM WALLS AND INDIVIDUAL CORNER ROUNDINGS */}
                  {((selectedObj as any).isRoom || (selectedObj as any).itemCategory === 'rooms') && (
                    <div className="space-y-4 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                      <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2">
                        <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Room Shapes</span>
                      </div>
                      
                      {/* Individual Wall Visibility */}
                      <div className="space-y-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Visible Walls:</span>
                        <div className="grid grid-cols-2 gap-2">
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.wallTop}
                              onChange={(e) => handlePropChange('wallTop', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Top</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.wallRight}
                              onChange={(e) => handlePropChange('wallRight', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Right</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.wallBottom}
                              onChange={(e) => handlePropChange('wallBottom', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-755">Bottom</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.wallLeft}
                              onChange={(e) => handlePropChange('wallLeft', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Left</span>
                          </label>
                        </div>
                        <p className="text-[10px] text-slate-500 leading-normal mt-1">
                          Hint: Hide overlapping inner walls to connect rooms and create complex L/T-shapes.
                        </p>
                      </div>

                      {/* Individual corners rounding */}
                      <div className="space-y-2 pt-2 border-t border-slate-200">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Round Corners:</span>
                        <div className="grid grid-cols-2 gap-2">
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.roundTL}
                              onChange={(e) => handlePropChange('roundTL', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Top-Left</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.roundTR}
                              onChange={(e) => handlePropChange('roundTR', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Top-Right</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.roundBR}
                              onChange={(e) => handlePropChange('roundBR', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Bottom-Right</span>
                          </label>
                          <label className="flex items-center gap-2 cursor-pointer bg-white border border-slate-200 rounded-lg p-2 hover:bg-slate-50 transition">
                            <input
                              type="checkbox"
                              className="accent-indigo-600 h-4 w-4 rounded"
                              checked={objProperties.roundBL}
                              onChange={(e) => handlePropChange('roundBL', e.target.checked)}
                            />
                            <span className="text-xs font-semibold text-slate-750">Bottom-Left</span>
                          </label>
                        </div>
                        
                        {(objProperties.roundTL || objProperties.roundTR || objProperties.roundBL || objProperties.roundBR) && (
                          <div className="space-y-1 mt-2.5">
                            <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase">
                              <span>Radius:</span>
                              <span className="font-mono text-slate-650">{Math.round(objProperties.cornerRadius * scaleRatio)} cm</span>
                            </div>
                            <input
                              type="range"
                              min="5"
                              max="150"
                              step="5"
                              className="w-full h-1 accent-indigo-600 bg-slate-200 rounded-lg cursor-pointer"
                              value={Math.round(objProperties.cornerRadius * scaleRatio)}
                              onChange={(e) => handlePropChange('cornerRadius', Math.max(1, parseFloat(e.target.value) / scaleRatio))}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Room Merging and Unity Section */}
                  {selectedObj && selectedObj.type !== 'text' && selectedObj.type !== 'i-text' && (
                    <div className="space-y-3 p-4 bg-indigo-50/40 border border-indigo-150 rounded-xl text-left">
                      <span className="text-xs font-bold text-indigo-900 uppercase tracking-wider flex items-center gap-1.5 border-b border-indigo-100 pb-2">
                        <span>🔗</span> Połącz kształty / Merge Shapes
                      </span>
                      {objProperties.mergedId ? (
                        <div className="space-y-2">
                          <div className="flex items-center gap-1.5 p-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs">
                            <span className="text-sm">✓</span>
                            <div className="leading-tight">
                              <p className="font-bold">Połączone kształty / Connected Unit</p>
                              <p className="text-[10px] text-emerald-600 font-semibold">Zablokowane razem. Przesuwanie porusza oba elementy.</p>
                            </div>
                          </div>
                          <button
                            onClick={disconnectRooms}
                            className="w-full py-2 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold rounded-lg text-xs tracking-wide transition active:bg-rose-150 cursor-pointer uppercase"
                          >
                            🔗 Rozłącz elementy / Separate Shapes
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <p className="text-xs text-slate-600 leading-normal font-semibold">
                            Merge selected touching/overlapping shapes into a single room.
                          </p>
                          <p className="text-[11px] text-slate-500 leading-tight">
                            Zaznacz dwa kształty (Shift + klik lub zaznacz obszar), albo przysuń je do siebie i kliknij poniższy przycisk, aby połączyć je w jedno pomieszczenie.
                          </p>
                          <button
                            onClick={mergeSelectedRooms}
                            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold rounded-lg text-xs tracking-wide transition active:bg-indigo-800 shadow-sm flex items-center justify-center gap-1.5 cursor-pointer uppercase mt-1"
                          >
                            🔗 Połącz kształty / Merge Shapes
                          </button>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="h-[1px] bg-slate-100 pt-1"></div>

                  {/* DUPLICATE AND ORDER LAYERS COHESION */}
                  <div className="space-y-2">
                    <p className="block text-xs text-slate-500 font-semibold uppercase tracking-wider"> Layer Ordering & Hierarchy </p>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => changeObjectLayer('front')}
                        className="flex justify-center items-center gap-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 p-2.5 text-xs font-semibold text-slate-705 transition shadow-sm"
                        title="Bring item to front layer"
                      >
                        Bring to Front
                      </button>
                      <button
                        onClick={() => changeObjectLayer('back')}
                        className="flex justify-center items-center gap-1.5 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 p-2.5 text-xs font-semibold text-slate-705 transition shadow-sm"
                        title="Send item to background layer"
                      >
                        Send to Back
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-2 mt-2">
                      <button
                        onClick={duplicateActiveObject}
                        className="w-full flex justify-center items-center gap-2 rounded-lg bg-indigo-50 border border-indigo-200 hover:bg-indigo-100/70 p-2.5 text-xs font-bold text-indigo-700 transition"
                      >
                        <Copy className="h-3.5 w-3.5" />
                        Clone Selected Element
                      </button>
                    </div>
                  </div>

                  {/* DESTRUCTIVE TRASH TRIGGER */}
                  <div className="pt-2">
                    <button
                      onClick={deleteActiveObject}
                      className="w-full flex items-center justify-center gap-2 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 p-3 text-xs font-bold tracking-wider transition uppercase"
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete from Workspace
                    </button>
                  </div>

                </div>

              </div>
              )
            ) : (
              <div className="p-6 text-center text-slate-400 space-y-6">
                
                {/* No element selected default state screen */}
                <div className="flex flex-col items-center justify-center py-8 space-y-3">
                  <div className="h-12 w-12 rounded-full border border-dashed border-slate-300 flex items-center justify-center text-slate-400">
                    <Info className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-700 text-sm">No Active Selection</h4>
                    <p className="text-[11px] text-slate-500 mt-1 max-w-[220px] mx-auto leading-relaxed">
                      Select any element or room on the canvas board to adjust coordinates, labels, sizing, or delete them.
                    </p>
                  </div>
                </div>

                {/* DYNAMIC ROOM SCHEDULE (ZESTAWIENIE POMIESZCZEŃ) CHART */}
                <div className="border-t border-slate-100 pt-6 text-left space-y-4">
                  <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center justify-between">
                    <span>Rooms Index & Schedule:</span>
                    <span className="font-mono text-emerald-750 text-xs px-2 py-0.5 bg-emerald-50 rounded-md border border-emerald-250">
                      {totalApartmentArea.toFixed(2)} m²
                    </span>
                  </h3>
                  
                  {roomsList.length > 0 ? (
                    <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                      {roomsList.map((room) => (
                        <div
                          key={room.id}
                          className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100/70 transition-colors"
                        >
                          <div className="flex items-center gap-2.5">
                            <span 
                              className="h-3 w-3 rounded border" 
                              style={{ borderColor: room.color, backgroundColor: `${room.color}33` }} 
                            />
                            <div>
                              <p className="text-xs font-bold text-slate-700">{room.label}</p>
                              <p className="text-[10px] text-slate-505 font-mono mt-0.5">{room.dimensions}</p>
                            </div>
                          </div>
                          
                          <p className="font-mono text-xs font-bold text-slate-650 bg-white px-2 py-1 rounded border border-slate-200">
                            {room.area.toFixed(2)} m²
                          </p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-4 rounded-xl border border-dashed border-slate-200 text-center bg-slate-50">
                      <p className="text-[11px] text-slate-500">
                        Add "Room" compartments from the left Elements Catalog to populate this dynamic metric calculator schedule.
                      </p>
                    </div>
                  )}
                </div>

                {/* Short instructions list */}
                <div className="border-t border-slate-100 pt-6 text-left space-y-2">
                  <h4 className="text-[11px] font-bold text-slate-555 uppercase tracking-widest">Hotkey Shortcuts:</h4>
                  <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-500">
                    <div>
                      <kbd className="font-mono bg-slate-100 px-1.5 py-1.5 rounded border border-slate-200 mr-1 shadow-sm text-slate-600">Del</kbd> Delete selected
                    </div>
                    <div>
                      <kbd className="font-mono bg-slate-100 px-1.5 py-1.5 rounded border border-slate-200 mr-1 shadow-sm text-slate-600">Pan</kbd> Space + drag view
                    </div>
                  </div>
                </div>

              </div>
            )}
          </div>
        </aside>

      </main>

      {/* DETAILED SAVE / LOAD MANAGEMENT MODAL */}
      {showSaveLoadModal && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" id="save-load-modal">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl flex flex-col">
            
            <div className="p-5 border-b border-slate-200 flex justify-between items-center">
              <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-indigo-550" />
                Local Storage - Saved Templates
              </h3>
              <button
                onClick={() => setShowSaveLoadModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-705 hover:bg-slate-100 transition"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 flex-grow overflow-y-auto max-h-[400px]">
              
              {/* Project Title Edit Box */}
              <div className="space-y-2">
                <label htmlFor="modal-project-name" className="block text-xs font-bold text-slate-450 uppercase tracking-wider"> Current Layout Name </label>
                <div className="flex gap-2">
                  <input
                    id="modal-project-name"
                    type="text"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    className="flex-grow bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 px-3.5 py-2 text-sm rounded-xl text-slate-800 font-bold"
                    placeholder="Enter layout name..."
                  />
                  <button
                    onClick={() => {
                      saveProjectToStore();
                    }}
                    className="bg-indigo-600 hover:bg-indigo-750 text-white font-bold text-xs px-4 rounded-xl shadow-sm cursor-pointer flex items-center gap-1.5 transition-colors"
                  >
                    <Save className="h-3.5 w-3.5" />
                    Save New Layout
                  </button>
                </div>
              </div>

              <div className="h-[1px] bg-slate-100 my-4"></div>

              {/* Saved blueprints array listing */}
              <p className="text-xs font-bold text-slate-450 uppercase tracking-wider">Saved Layouts in browser:</p>
              
              <div className="space-y-2.5">
                {savedProjects.length > 0 ? (
                  savedProjects.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => loadProjectFromStore(p)}
                      className="group p-4 rounded-xl bg-slate-50 hover:bg-indigo-50/40 border border-slate-200 hover:border-indigo-500/50 flex align-middle justify-between hover:scale-[1.01] cursor-pointer transition-all"
                    >
                      <div>
                        <h4 className="font-bold text-sm text-slate-800 group-hover:text-indigo-600 transition-colors">
                          {p.name}
                        </h4>
                        <div className="flex gap-4 items-center mt-1.5 text-[11px] font-mono text-slate-500">
                          <span>Updated: {p.updatedAt}</span>
                          <span>Scale: 1px = {p.scaleFactor || 2}cm</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => deleteProjectFromStore(p.id, e)}
                          className="p-1 px-2.5 text-[10px] font-bold uppercase tracking-wider text-red-600 border border-red-200 rounded-lg hover:bg-red-50 hover:text-red-705 transition"
                          title="Delete record permanently"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 border border-dashed border-slate-200 text-center rounded-xl bg-slate-50">
                    <p className="text-xs text-slate-500">
                      No saved layouts found in local browser storage. Type a name above and click "Save New Layout".
                    </p>
                  </div>
                )}
              </div>

            </div>

            <div className="p-4 border-t border-slate-200 bg-slate-50 text-[11px] text-slate-500 flex items-center justify-between">
              <span>* Layouts are securely preserved inside the current web browser's local storage (Local Storage).</span>
              <button
                onClick={() => setShowSaveLoadModal(false)}
                className="bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 font-semibold px-3 py-1.5 rounded-lg text-xs transition"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Toast Notification Container */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 pointer-events-none">
          <div className="bg-slate-900 border border-slate-800 text-white rounded-xl shadow-2xl px-4.5 py-3 text-xs font-bold font-sans tracking-wide flex items-center gap-2.5 max-w-sm pointer-events-auto">
            <span className="text-emerald-400 text-base">✓</span>
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Confirmation Dialog Overlay */}
      {confirmDialog && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-[2px] z-55 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 shadow-2xl rounded-2xl p-5 max-w-sm w-full space-y-4 animate-scale-up">
            <div className="space-y-1.5 animate-fade-in">
              <h4 className="text-sm font-extrabold text-slate-855 uppercase tracking-wider text-indigo-700">Please Confirm</h4>
              <p className="text-xs text-slate-600 leading-relaxed font-semibold">{confirmDialog.message}</p>
            </div>
            <div className="flex items-center gap-2.5 justify-end">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-3.5 py-2 text-xs font-bold text-slate-500 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  confirmDialog.onConfirm();
                  setConfirmDialog(null);
                }}
                className="px-4 py-2 text-xs font-extrabold text-white bg-indigo-600 hover:bg-indigo-700 transition active:bg-indigo-800 rounded-xl shadow-sm cursor-pointer"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
